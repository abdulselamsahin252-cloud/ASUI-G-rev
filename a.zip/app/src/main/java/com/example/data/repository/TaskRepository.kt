package com.example.data.repository

import com.example.data.local.TaskDao
import com.example.data.local.TaskEntity
import kotlinx.coroutines.flow.Flow

class TaskRepository(private val taskDao: TaskDao) {
    val allTasks: Flow<List<TaskEntity>> = taskDao.observeAllTasks()

    suspend fun upsertTask(task: TaskEntity): Long {
        return taskDao.upsertTask(task.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun restoreTask(task: TaskEntity) {
        taskDao.upsertTask(task)
    }

    suspend fun deleteTask(task: TaskEntity) {
        taskDao.deleteTask(task)
    }

    suspend fun clearCompleted() {
        taskDao.deleteAllCompleted()
    }
}
