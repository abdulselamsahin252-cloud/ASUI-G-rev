package com.example.data.preferences

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "asui_gorev_settings"
)

enum class AppThemeMode {
    LIGHT,
    DARK,
    AMOLED,
    NEON
}

enum class AppLanguage(val tag: String) {
    SYSTEM("system"),
    TURKISH("tr"),
    ENGLISH("en");

    companion object {
        fun fromTag(tag: String?): AppLanguage =
            entries.firstOrNull { it.tag == tag } ?: SYSTEM
    }
}

enum class WallpaperQuality(val maxDimension: Int) {
    LOW(640),
    MEDIUM(1080),
    HIGH(1600),
    ORIGINAL(2800)
}

enum class HomeLayoutMode {
    AUTO,
    LIST,
    GRID
}

enum class CardDensity {
    COMFORTABLE,
    COMPACT
}

enum class FabStyleMode {
    EXTENDED,
    COMPACT_ICON,
    CENTER_EXTENDED
}

enum class WidgetStyleMode {
    MATCH_APP,
    AMOLED,
    NEON,
    GLASS
}

data class ReminderTime(
    val hour: Int,
    val minute: Int
) : Comparable<ReminderTime> {
    override fun compareTo(other: ReminderTime): Int =
        (hour * 60 + minute) - (other.hour * 60 + other.minute)

    fun formatted(): String = "%02d:%02d".format(hour, minute)

    companion object {
        fun parse(raw: String): ReminderTime? {
            val parts = raw.trim().split(":")
            if (parts.size != 2) return null
            val h = parts[0].toIntOrNull() ?: return null
            val m = parts[1].toIntOrNull() ?: return null
            if (h !in 0..23 || m !in 0..59) return null
            return ReminderTime(h, m)
        }
    }
}

data class AppSettings(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val language: AppLanguage = AppLanguage.SYSTEM,
    // App Wallpaper
    val wallpaperPath: String? = null,
    val wallpaperBlur: Float = 0f,
    val wallpaperSharpness: Float = 1.0f,
    val wallpaperDarkness: Float = 0.45f,
    val wallpaperQuality: WallpaperQuality = WallpaperQuality.HIGH,
    // Home Screen Customization
    val defaultStepAmount: Int = 10,
    val homeLayoutMode: HomeLayoutMode = HomeLayoutMode.AUTO,
    val cardDensity: CardDensity = CardDensity.COMFORTABLE,
    val fabStyleMode: FabStyleMode = FabStyleMode.EXTENDED,
    val cardCornerRadius: Int = 18,
    val cardOpacity: Float = 0.84f,
    val showOverviewCard: Boolean = true,
    val showStatusFilters: Boolean = true,
    val showCategoryFilters: Boolean = true,
    val showNotesOnCards: Boolean = true,
    val showBadgesOnCards: Boolean = true,
    val showDeadlinesOnCards: Boolean = true,
    // Widget Customization
    val widgetWallpaperPath: String? = null,
    val widgetBlur: Float = 4f,
    val widgetSharpness: Float = 1.0f,
    val widgetDarkness: Float = 0.50f,
    val widgetStyleMode: WidgetStyleMode = WidgetStyleMode.MATCH_APP,
    // Reminder Settings
    val remindersEnabled: Boolean = false,
    val reminderDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7), // Calendar.MONDAY..SUNDAY (1=Mon..7=Sun ISO)
    val reminderTimes: List<ReminderTime> = listOf(ReminderTime(9, 0), ReminderTime(20, 0))
)

object LocaleStorage {
    private const val PREFS_NAME = "asui_locale_prefs"
    private const val KEY_LANG = "language_tag"

    fun getSavedLanguageTag(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LANG, AppLanguage.SYSTEM.tag) ?: AppLanguage.SYSTEM.tag
    }

    fun saveLanguageTag(context: Context, tag: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANG, tag)
            .apply()
    }
}

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val WALLPAPER_PATH = stringPreferencesKey("wallpaper_path")
        val WALLPAPER_BLUR = floatPreferencesKey("wallpaper_blur")
        val WALLPAPER_SHARPNESS = floatPreferencesKey("wallpaper_sharpness")
        val WALLPAPER_DARKNESS = floatPreferencesKey("wallpaper_darkness")
        val WALLPAPER_QUALITY = stringPreferencesKey("wallpaper_quality")

        val DEFAULT_STEP_AMOUNT = intPreferencesKey("default_step_amount")
        val HOME_LAYOUT_MODE = stringPreferencesKey("home_layout_mode")
        val CARD_DENSITY = stringPreferencesKey("card_density")
        val FAB_STYLE_MODE = stringPreferencesKey("fab_style_mode")
        val CARD_CORNER_RADIUS = intPreferencesKey("card_corner_radius")
        val CARD_OPACITY = floatPreferencesKey("card_opacity")
        val SHOW_OVERVIEW = booleanPreferencesKey("show_overview")
        val SHOW_STATUS_FILTERS = booleanPreferencesKey("show_status_filters")
        val SHOW_CATEGORY_FILTERS = booleanPreferencesKey("show_category_filters")
        val SHOW_NOTES = booleanPreferencesKey("show_notes")
        val SHOW_BADGES = booleanPreferencesKey("show_badges")
        val SHOW_DEADLINES = booleanPreferencesKey("show_deadlines")

        val WIDGET_WALLPAPER_PATH = stringPreferencesKey("widget_wallpaper_path")
        val WIDGET_BLUR = floatPreferencesKey("widget_blur")
        val WIDGET_SHARPNESS = floatPreferencesKey("widget_sharpness")
        val WIDGET_DARKNESS = floatPreferencesKey("widget_darkness")
        val WIDGET_STYLE = stringPreferencesKey("widget_style")

        val REMINDERS_ENABLED = booleanPreferencesKey("reminders_enabled")
        val REMINDER_DAYS = stringPreferencesKey("reminder_days")
        val REMINDER_TIMES = stringPreferencesKey("reminder_times")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        val savedPath = prefs[Keys.WALLPAPER_PATH]?.takeIf { File(it).exists() }
        val savedWidgetPath = prefs[Keys.WIDGET_WALLPAPER_PATH]?.takeIf { File(it).exists() }

        val days = prefs[Keys.REMINDER_DAYS]
            ?.split(",")
            ?.mapNotNull { it.trim().toIntOrNull() }
            ?.filter { it in 1..7 }
            ?.toSet()
            ?.takeIf { it.isNotEmpty() }
            ?: setOf(1, 2, 3, 4, 5, 6, 7)

        val times = prefs[Keys.REMINDER_TIMES]
            ?.split(",")
            ?.mapNotNull { ReminderTime.parse(it) }
            ?.distinct()
            ?.sorted()
            ?.takeIf { it.isNotEmpty() }
            ?: listOf(ReminderTime(9, 0), ReminderTime(20, 0))

        AppSettings(
            themeMode = runCatching {
                AppThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: AppThemeMode.DARK.name)
            }.getOrDefault(AppThemeMode.DARK),
            language = AppLanguage.fromTag(prefs[Keys.LANGUAGE]),
            wallpaperPath = savedPath,
            wallpaperBlur = (prefs[Keys.WALLPAPER_BLUR] ?: 0f).coerceIn(0f, 30f),
            wallpaperSharpness = (prefs[Keys.WALLPAPER_SHARPNESS] ?: 1.0f).coerceIn(0.2f, 1.8f),
            wallpaperDarkness = (prefs[Keys.WALLPAPER_DARKNESS] ?: 0.45f).coerceIn(0f, 0.92f),
            wallpaperQuality = runCatching {
                WallpaperQuality.valueOf(prefs[Keys.WALLPAPER_QUALITY] ?: WallpaperQuality.HIGH.name)
            }.getOrDefault(WallpaperQuality.HIGH),
            defaultStepAmount = (prefs[Keys.DEFAULT_STEP_AMOUNT] ?: 10).coerceIn(1, 100),
            homeLayoutMode = runCatching {
                HomeLayoutMode.valueOf(prefs[Keys.HOME_LAYOUT_MODE] ?: HomeLayoutMode.AUTO.name)
            }.getOrDefault(HomeLayoutMode.AUTO),
            cardDensity = runCatching {
                CardDensity.valueOf(prefs[Keys.CARD_DENSITY] ?: CardDensity.COMFORTABLE.name)
            }.getOrDefault(CardDensity.COMFORTABLE),
            fabStyleMode = runCatching {
                FabStyleMode.valueOf(prefs[Keys.FAB_STYLE_MODE] ?: FabStyleMode.EXTENDED.name)
            }.getOrDefault(FabStyleMode.EXTENDED),
            cardCornerRadius = (prefs[Keys.CARD_CORNER_RADIUS] ?: 18).coerceIn(8, 28),
            cardOpacity = (prefs[Keys.CARD_OPACITY] ?: 0.84f).coerceIn(0.40f, 1.0f),
            showOverviewCard = prefs[Keys.SHOW_OVERVIEW] ?: true,
            showStatusFilters = prefs[Keys.SHOW_STATUS_FILTERS] ?: true,
            showCategoryFilters = prefs[Keys.SHOW_CATEGORY_FILTERS] ?: true,
            showNotesOnCards = prefs[Keys.SHOW_NOTES] ?: true,
            showBadgesOnCards = prefs[Keys.SHOW_BADGES] ?: true,
            showDeadlinesOnCards = prefs[Keys.SHOW_DEADLINES] ?: true,
            widgetWallpaperPath = savedWidgetPath,
            widgetBlur = (prefs[Keys.WIDGET_BLUR] ?: 4f).coerceIn(0f, 25f),
            widgetSharpness = (prefs[Keys.WIDGET_SHARPNESS] ?: 1.0f).coerceIn(0.2f, 1.8f),
            widgetDarkness = (prefs[Keys.WIDGET_DARKNESS] ?: 0.50f).coerceIn(0f, 0.92f),
            widgetStyleMode = runCatching {
                WidgetStyleMode.valueOf(prefs[Keys.WIDGET_STYLE] ?: WidgetStyleMode.MATCH_APP.name)
            }.getOrDefault(WidgetStyleMode.MATCH_APP),
            remindersEnabled = prefs[Keys.REMINDERS_ENABLED] ?: false,
            reminderDays = days,
            reminderTimes = times
        )
    }

    suspend fun getSettingsOnce(): AppSettings = settingsFlow.first()

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.settingsDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setLanguage(language: AppLanguage) {
        LocaleStorage.saveLanguageTag(context, language.tag)
        context.settingsDataStore.edit { it[Keys.LANGUAGE] = language.tag }
    }

    suspend fun saveWallpaperFromUri(uri: Uri): Boolean = copyImageLocally(
        uri = uri,
        prefix = "custom_wallpaper_",
        key = Keys.WALLPAPER_PATH
    )

    suspend fun clearWallpaper() {
        deleteFilesWithPrefix("custom_wallpaper_")
        context.settingsDataStore.edit { it.remove(Keys.WALLPAPER_PATH) }
    }

    suspend fun setWallpaperBlur(blur: Float) {
        context.settingsDataStore.edit { it[Keys.WALLPAPER_BLUR] = blur.coerceIn(0f, 30f) }
    }

    suspend fun setWallpaperSharpness(sharpness: Float) {
        context.settingsDataStore.edit { it[Keys.WALLPAPER_SHARPNESS] = sharpness.coerceIn(0.2f, 1.8f) }
    }

    suspend fun setWallpaperDarkness(darkness: Float) {
        context.settingsDataStore.edit { it[Keys.WALLPAPER_DARKNESS] = darkness.coerceIn(0f, 0.92f) }
    }

    suspend fun setWallpaperQuality(quality: WallpaperQuality) {
        context.settingsDataStore.edit { it[Keys.WALLPAPER_QUALITY] = quality.name }
    }

    suspend fun resetWallpaperAdjustments() {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.WALLPAPER_BLUR] = 0f
            prefs[Keys.WALLPAPER_SHARPNESS] = 1.0f
            prefs[Keys.WALLPAPER_DARKNESS] = 0.45f
            prefs[Keys.WALLPAPER_QUALITY] = WallpaperQuality.HIGH.name
        }
    }

    // Home Customization Setters
    suspend fun setDefaultStepAmount(step: Int) {
        context.settingsDataStore.edit { it[Keys.DEFAULT_STEP_AMOUNT] = step.coerceIn(1, 100) }
    }

    suspend fun setHomeLayoutMode(mode: HomeLayoutMode) {
        context.settingsDataStore.edit { it[Keys.HOME_LAYOUT_MODE] = mode.name }
    }

    suspend fun setCardDensity(density: CardDensity) {
        context.settingsDataStore.edit { it[Keys.CARD_DENSITY] = density.name }
    }

    suspend fun setFabStyleMode(mode: FabStyleMode) {
        context.settingsDataStore.edit { it[Keys.FAB_STYLE_MODE] = mode.name }
    }

    suspend fun setCardCornerRadius(radius: Int) {
        context.settingsDataStore.edit { it[Keys.CARD_CORNER_RADIUS] = radius.coerceIn(8, 28) }
    }

    suspend fun setCardOpacity(opacity: Float) {
        context.settingsDataStore.edit { it[Keys.CARD_OPACITY] = opacity.coerceIn(0.40f, 1.0f) }
    }

    suspend fun setShowOverviewCard(show: Boolean) {
        context.settingsDataStore.edit { it[Keys.SHOW_OVERVIEW] = show }
    }

    suspend fun setShowStatusFilters(show: Boolean) {
        context.settingsDataStore.edit { it[Keys.SHOW_STATUS_FILTERS] = show }
    }

    suspend fun setShowCategoryFilters(show: Boolean) {
        context.settingsDataStore.edit { it[Keys.SHOW_CATEGORY_FILTERS] = show }
    }

    suspend fun setShowNotesOnCards(show: Boolean) {
        context.settingsDataStore.edit { it[Keys.SHOW_NOTES] = show }
    }

    suspend fun setShowBadgesOnCards(show: Boolean) {
        context.settingsDataStore.edit { it[Keys.SHOW_BADGES] = show }
    }

    suspend fun setShowDeadlinesOnCards(show: Boolean) {
        context.settingsDataStore.edit { it[Keys.SHOW_DEADLINES] = show }
    }

    suspend fun resetHomeCustomization() {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.DEFAULT_STEP_AMOUNT] = 10
            prefs[Keys.HOME_LAYOUT_MODE] = HomeLayoutMode.AUTO.name
            prefs[Keys.CARD_DENSITY] = CardDensity.COMFORTABLE.name
            prefs[Keys.FAB_STYLE_MODE] = FabStyleMode.EXTENDED.name
            prefs[Keys.CARD_CORNER_RADIUS] = 18
            prefs[Keys.CARD_OPACITY] = 0.84f
            prefs[Keys.SHOW_OVERVIEW] = true
            prefs[Keys.SHOW_STATUS_FILTERS] = true
            prefs[Keys.SHOW_CATEGORY_FILTERS] = true
            prefs[Keys.SHOW_NOTES] = true
            prefs[Keys.SHOW_BADGES] = true
            prefs[Keys.SHOW_DEADLINES] = true
        }
    }

    // Widget Customization Setters
    suspend fun saveWidgetWallpaperFromUri(uri: Uri): Boolean = copyImageLocally(
        uri = uri,
        prefix = "widget_wallpaper_",
        key = Keys.WIDGET_WALLPAPER_PATH
    )

    suspend fun clearWidgetWallpaper() {
        deleteFilesWithPrefix("widget_wallpaper_")
        context.settingsDataStore.edit { it.remove(Keys.WIDGET_WALLPAPER_PATH) }
    }

    suspend fun setWidgetBlur(blur: Float) {
        context.settingsDataStore.edit { it[Keys.WIDGET_BLUR] = blur.coerceIn(0f, 25f) }
    }

    suspend fun setWidgetSharpness(sharpness: Float) {
        context.settingsDataStore.edit { it[Keys.WIDGET_SHARPNESS] = sharpness.coerceIn(0.2f, 1.8f) }
    }

    suspend fun setWidgetDarkness(darkness: Float) {
        context.settingsDataStore.edit { it[Keys.WIDGET_DARKNESS] = darkness.coerceIn(0f, 0.92f) }
    }

    suspend fun setWidgetStyleMode(style: WidgetStyleMode) {
        context.settingsDataStore.edit { it[Keys.WIDGET_STYLE] = style.name }
    }

    // Reminder Setters
    suspend fun setRemindersEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.REMINDERS_ENABLED] = enabled }
    }

    suspend fun toggleReminderDay(dayIso: Int) {
        if (dayIso !in 1..7) return
        context.settingsDataStore.edit { prefs ->
            val current = prefs[Keys.REMINDER_DAYS]
                ?.split(",")
                ?.mapNotNull { it.trim().toIntOrNull() }
                ?.filter { it in 1..7 }
                ?.toMutableSet()
                ?: mutableSetOf(1, 2, 3, 4, 5, 6, 7)

            if (current.contains(dayIso) && current.size > 1) {
                current.remove(dayIso)
            } else {
                current.add(dayIso)
            }
            prefs[Keys.REMINDER_DAYS] = current.sorted().joinToString(",")
        }
    }

    suspend fun addReminderTime(time: ReminderTime) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[Keys.REMINDER_TIMES]
                ?.split(",")
                ?.mapNotNull { ReminderTime.parse(it) }
                ?.toMutableSet()
                ?: mutableSetOf(ReminderTime(9, 0), ReminderTime(20, 0))
            current.add(time)
            prefs[Keys.REMINDER_TIMES] = current.sorted().joinToString(",") { it.formatted() }
        }
    }

    suspend fun removeReminderTime(time: ReminderTime) {
        context.settingsDataStore.edit { prefs ->
            val current = prefs[Keys.REMINDER_TIMES]
                ?.split(",")
                ?.mapNotNull { ReminderTime.parse(it) }
                ?.toMutableSet()
                ?: mutableSetOf(ReminderTime(9, 0), ReminderTime(20, 0))
            if (current.size > 1) {
                current.remove(time)
                prefs[Keys.REMINDER_TIMES] = current.sorted().joinToString(",") { it.formatted() }
            }
        }
    }

    private suspend fun copyImageLocally(
        uri: Uri,
        prefix: String,
        key: Preferences.Key<String>
    ): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val destFile = File(context.filesDir, "${prefix}${System.currentTimeMillis()}.jpg")
            deleteFilesWithPrefix(prefix)

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext false

            context.settingsDataStore.edit { prefs ->
                prefs[key] = destFile.absolutePath
            }
            true
        }.getOrDefault(false)
    }

    private fun deleteFilesWithPrefix(prefix: String) {
        context.filesDir.listFiles { file ->
            file.name.startsWith(prefix)
        }?.forEach { it.delete() }
    }
}
