package com.example.data.preferences

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "asui_gorev_settings"
)

enum class AppThemeMode {
    LIGHT,
    DARK,
    AMOLED,
    NEON
}

enum class AppLanguage(val tag: String) {
    SYSTEM("system"),
    TURKISH("tr"),
    ENGLISH("en");

    companion object {
        fun fromTag(tag: String?): AppLanguage =
            entries.firstOrNull { it.tag == tag } ?: SYSTEM
    }
}

enum class WallpaperQuality(val maxDimension: Int) {
    LOW(640),
    MEDIUM(1080),
    HIGH(1600),
    ORIGINAL(2800)
}

data class AppSettings(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val language: AppLanguage = AppLanguage.SYSTEM,
    val wallpaperPath: String? = null,
    val wallpaperBlur: Float = 0f,
    val wallpaperSharpness: Float = 1.0f,
    val wallpaperDarkness: Float = 0.45f,
    val wallpaperQuality: WallpaperQuality = WallpaperQuality.HIGH
)

object LocaleStorage {
    private const val PREFS_NAME = "asui_locale_prefs"
    private const val KEY_LANG = "language_tag"

    fun getSavedLanguageTag(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LANG, AppLanguage.SYSTEM.tag) ?: AppLanguage.SYSTEM.tag
    }

    fun saveLanguageTag(context: Context, tag: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANG, tag)
            .apply()
    }
}

class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val WALLPAPER_PATH = stringPreferencesKey("wallpaper_path")
        val WALLPAPER_BLUR = floatPreferencesKey("wallpaper_blur")
        val WALLPAPER_SHARPNESS = floatPreferencesKey("wallpaper_sharpness")
        val WALLPAPER_DARKNESS = floatPreferencesKey("wallpaper_darkness")
        val WALLPAPER_QUALITY = stringPreferencesKey("wallpaper_quality")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        val savedPath = prefs[Keys.WALLPAPER_PATH]?.takeIf { path ->
            File(path).exists()
        }
        AppSettings(
            themeMode = runCatching {
                AppThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: AppThemeMode.DARK.name)
            }.getOrDefault(AppThemeMode.DARK),
            language = AppLanguage.fromTag(prefs[Keys.LANGUAGE]),
            wallpaperPath = savedPath,
            wallpaperBlur = (prefs[Keys.WALLPAPER_BLUR] ?: 0f).coerceIn(0f, 30f),
            wallpaperSharpness = (prefs[Keys.WALLPAPER_SHARPNESS] ?: 1.0f).coerceIn(0.2f, 1.8f),
            wallpaperDarkness = (prefs[Keys.WALLPAPER_DARKNESS] ?: 0.45f).coerceIn(0f, 0.92f),
            wallpaperQuality = runCatching {
                WallpaperQuality.valueOf(prefs[Keys.WALLPAPER_QUALITY] ?: WallpaperQuality.HIGH.name)
            }.getOrDefault(WallpaperQuality.HIGH)
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun setLanguage(language: AppLanguage) {
        LocaleStorage.saveLanguageTag(context, language.tag)
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.tag
        }
    }

    suspend fun saveWallpaperFromUri(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val destFile = File(context.filesDir, "custom_wallpaper_${System.currentTimeMillis()}.jpg")
            // Clean up older wallpaper files
            context.filesDir.listFiles { file ->
                file.name.startsWith("custom_wallpaper_")
            }?.forEach { old -> old.delete() }

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext false

            context.settingsDataStore.edit { prefs ->
                prefs[Keys.WALLPAPER_PATH] = destFile.absolutePath
            }
            true
        }.getOrDefault(false)
    }

    suspend fun clearWallpaper() {
        withContext(Dispatchers.IO) {
            context.filesDir.listFiles { file ->
                file.name.startsWith("custom_wallpaper_")
            }?.forEach { it.delete() }
        }
        context.settingsDataStore.edit { prefs ->
            prefs.remove(Keys.WALLPAPER_PATH)
        }
    }

    suspend fun setWallpaperBlur(blur: Float) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.WALLPAPER_BLUR] = blur.coerceIn(0f, 30f)
        }
    }

    suspend fun setWallpaperSharpness(sharpness: Float) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.WALLPAPER_SHARPNESS] = sharpness.coerceIn(0.2f, 1.8f)
        }
    }

    suspend fun setWallpaperDarkness(darkness: Float) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.WALLPAPER_DARKNESS] = darkness.coerceIn(0f, 0.92f)
        }
    }

    suspend fun setWallpaperQuality(quality: WallpaperQuality) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.WALLPAPER_QUALITY] = quality.name
        }
    }

    suspend fun resetWallpaperAdjustments() {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.WALLPAPER_BLUR] = 0f
            prefs[Keys.WALLPAPER_SHARPNESS] = 1.0f
            prefs[Keys.WALLPAPER_DARKNESS] = 0.45f
            prefs[Keys.WALLPAPER_QUALITY] = WallpaperQuality.HIGH.name
        }
    }
}
