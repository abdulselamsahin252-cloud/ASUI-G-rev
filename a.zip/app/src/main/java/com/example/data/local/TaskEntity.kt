package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import kotlin.math.roundToInt

enum class TaskCategory {
    GENEL,
    IS,
    KISISEL,
    EGITIM,
    SAGLIK,
    ALISVERIS
}

enum class TaskPriority(val weight: Int) {
    DUSUK(1),
    ORTA(2),
    YUKSEK(3)
}

enum class ProgressMode {
    PERCENTAGE,
    AMOUNT
}

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val note: String = "",
    val category: TaskCategory = TaskCategory.GENEL,
    val priority: TaskPriority = TaskPriority.ORTA,
    val progressMode: ProgressMode = ProgressMode.PERCENTAGE,
    val progressPercent: Int = 0,
    val completedAmount: Int = 0,
    val targetAmount: Int = 10,
    val unitLabel: String = "",
    val lastNonFullPercent: Int = 0,
    val lastNonFullAmount: Int = 0,
    val customStepAmount: Int? = null,
    val durationDays: Int = 0,
    val durationHours: Int = 0,
    val deadlineAt: Long? = null,
    val deadlineNotified: Boolean = false,
    val reminderEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val effectivePercent: Int
        get() = when (progressMode) {
            ProgressMode.PERCENTAGE -> progressPercent.coerceIn(0, 100)
            ProgressMode.AMOUNT -> {
                if (targetAmount <= 0) 0
                else ((completedAmount.toFloat() / targetAmount.toFloat()) * 100f)
                    .roundToInt()
                    .coerceIn(0, 100)
            }
        }

    val isCompleted: Boolean
        get() = effectivePercent >= 100

    val hasDeadline: Boolean
        get() = deadlineAt != null && (durationDays > 0 || durationHours > 0)

    fun effectiveStep(defaultStep: Int): Int =
        (customStepAmount ?: defaultStep).coerceAtLeast(1)
}

class TaskConverters {
    @TypeConverter
    fun fromCategory(value: TaskCategory): String = value.name

    @TypeConverter
    fun toCategory(value: String): TaskCategory =
        runCatching { TaskCategory.valueOf(value) }.getOrDefault(TaskCategory.GENEL)

    @TypeConverter
    fun fromPriority(value: TaskPriority): String = value.name

    @TypeConverter
    fun toPriority(value: String): TaskPriority =
        runCatching { TaskPriority.valueOf(value) }.getOrDefault(TaskPriority.ORTA)

    @TypeConverter
    fun fromProgressMode(value: ProgressMode): String = value.name

    @TypeConverter
    fun toProgressMode(value: String): ProgressMode =
        runCatching { ProgressMode.valueOf(value) }.getOrDefault(ProgressMode.PERCENTAGE)
}
