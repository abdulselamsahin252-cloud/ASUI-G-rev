package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.ProgressMode
import com.example.data.local.TaskEntity
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.LocaleStorage
import java.util.Locale
import kotlin.math.roundToInt

object NotificationHelper {
    const val CHANNEL_REMINDERS = "asui_reminders_channel"
    const val CHANNEL_DEADLINES = "asui_deadlines_channel"
    private const val REMINDER_NOTIFICATION_ID = 7001

    fun localizedContext(base: Context): Context {
        val tag = LocaleStorage.getSavedLanguageTag(base)
        if (tag == AppLanguage.SYSTEM.tag) return base
        val locale = Locale.forLanguageTag(tag)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val ctx = localizedContext(context)
        val manager = ctx.getSystemService(NotificationManager::class.java) ?: return

        val reminderChannel = NotificationChannel(
            CHANNEL_REMINDERS,
            ctx.getString(R.string.notif_channel_reminders_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = ctx.getString(R.string.notif_channel_reminders_desc)
        }

        val deadlineChannel = NotificationChannel(
            CHANNEL_DEADLINES,
            ctx.getString(R.string.notif_channel_deadlines_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = ctx.getString(R.string.notif_channel_deadlines_desc)
        }

        manager.createNotificationChannel(reminderChannel)
        manager.createNotificationChannel(deadlineChannel)
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun showProgressReminderNotification(context: Context, allTasks: List<TaskEntity>) {
        if (!hasNotificationPermission(context)) return
        ensureChannels(context)
        val ctx = localizedContext(context)

        val activeTasks = allTasks.filter { !it.isCompleted && it.reminderEnabled }
        val openIntent = PendingIntent.getActivity(
            ctx,
            100,
            Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = ctx.getString(R.string.notif_reminder_title)
        val summaryLine: String
        val bigText: String

        if (activeTasks.isEmpty()) {
            summaryLine = ctx.getString(R.string.notif_reminder_empty)
            bigText = summaryLine
        } else {
            val avg = activeTasks.map { it.effectivePercent }.average().roundToInt()
            summaryLine = ctx.getString(R.string.notif_reminder_summary, activeTasks.size, avg)
            bigText = buildString {
                appendLine(summaryLine)
                activeTasks.take(5).forEach { task ->
                    val pct = task.effectivePercent
                    val amountPart = if (task.progressMode == ProgressMode.AMOUNT) {
                        val unit = if (task.unitLabel.isNotBlank()) " ${task.unitLabel}" else ""
                        " (${task.completedAmount}/${task.targetAmount}$unit)"
                    } else ""
                    val timePart = formatRemainingShort(ctx, task)?.let { " • $it" } ?: ""
                    appendLine("• ${task.title}: %$pct$amountPart$timePart")
                }
            }.trim()
        }

        val notification = NotificationCompat.Builder(ctx, CHANNEL_REMINDERS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(summaryLine)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(ctx).notify(REMINDER_NOTIFICATION_ID, notification)
        }
    }

    fun showDeadlineExpiredNotification(context: Context, task: TaskEntity) {
        if (!hasNotificationPermission(context) || task.isCompleted) return
        ensureChannels(context)
        val ctx = localizedContext(context)

        val openIntent = PendingIntent.getActivity(
            ctx,
            (2000 + task.id).toInt(),
            Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val durationText = formatDurationSummary(ctx, task.durationDays, task.durationHours)
        val percent = task.effectivePercent
        val title = ctx.getString(R.string.notif_deadline_title, task.title)
        val body = if (task.progressMode == ProgressMode.AMOUNT) {
            ctx.getString(
                R.string.notif_deadline_body_amount,
                durationText,
                task.completedAmount,
                task.targetAmount,
                task.unitLabel,
                percent
            ).replace("  ", " ")
        } else {
            ctx.getString(
                R.string.notif_deadline_body,
                durationText,
                percent
            )
        }

        val notification = NotificationCompat.Builder(ctx, CHANNEL_DEADLINES)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(ctx).notify((8000 + task.id).toInt(), notification)
        }
    }

    fun formatDurationSummary(context: Context, days: Int, hours: Int): String {
        val isTurkish = LocaleStorage.getSavedLanguageTag(context) == "tr" ||
            (LocaleStorage.getSavedLanguageTag(context) == "system" &&
                Locale.getDefault().language == "tr")

        return if (isTurkish) {
            when {
                days > 0 && hours > 0 -> "$days gün $hours saat"
                days > 0 -> "$days gün"
                hours > 0 -> "$hours saat"
                else -> "belirlenen"
            }
        } else {
            when {
                days > 0 && hours > 0 -> "${days}d ${hours}h"
                days > 0 -> "$days days"
                hours > 0 -> "$hours hours"
                else -> "the set"
            }
        }
    }

    fun formatRemainingShort(context: Context, task: TaskEntity): String? {
        val deadline = task.deadlineAt ?: return null
        if (task.isCompleted) return context.getString(R.string.deadline_done_on_time)
        val diff = deadline - System.currentTimeMillis()
        if (diff <= 0L) return context.getString(R.string.deadline_expired)

        val totalMinutes = (diff / 60_000L).toInt().coerceAtLeast(1)
        val totalHours = totalMinutes / 60
        val days = totalHours / 24
        val remHours = totalHours % 24

        return when {
            days > 0 && remHours > 0 -> context.getString(R.string.deadline_remaining_days_hours, days, remHours)
            days > 0 -> context.getString(R.string.deadline_remaining_days, days)
            totalHours > 0 -> context.getString(R.string.deadline_remaining_hours, totalHours)
            else -> context.getString(R.string.deadline_remaining_minutes, totalMinutes)
        }
    }
}
