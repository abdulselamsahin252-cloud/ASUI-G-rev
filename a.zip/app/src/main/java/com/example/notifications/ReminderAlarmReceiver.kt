package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.AppDatabase
import com.example.data.preferences.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.getInstance(appContext).taskDao()
                val settingsRepo = SettingsRepository(appContext)
                val settings = settingsRepo.getSettingsOnce()

                when (intent.action) {
                    ReminderScheduler.ACTION_PROGRESS_REMINDER -> {
                        val tasks = dao.getAllTasksOnce()
                        if (settings.remindersEnabled) {
                            NotificationHelper.showProgressReminderNotification(appContext, tasks)
                        }
                        ReminderScheduler.checkAndNotifyExpiredDeadlines(appContext)
                        ReminderScheduler.scheduleNextProgressReminder(appContext, settings)
                    }

                    ReminderScheduler.ACTION_DEADLINE_CHECK -> {
                        val taskId = intent.getLongExtra(ReminderScheduler.EXTRA_TASK_ID, -1L)
                        if (taskId > 0L) {
                            val task = dao.getTaskById(taskId)
                            if (task != null && !task.isCompleted && !task.deadlineNotified) {
                                NotificationHelper.showDeadlineExpiredNotification(appContext, task)
                                dao.markDeadlineNotified(task.id)
                            }
                        } else {
                            ReminderScheduler.checkAndNotifyExpiredDeadlines(appContext)
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
