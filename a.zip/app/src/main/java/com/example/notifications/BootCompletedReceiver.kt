package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.AppDatabase
import com.example.data.preferences.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = SettingsRepository(appContext).getSettingsOnce()
                val tasks = AppDatabase.getInstance(appContext).taskDao().getAllTasksOnce()
                ReminderScheduler.checkAndNotifyExpiredDeadlines(appContext)
                ReminderScheduler.scheduleAll(appContext, settings, tasks)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
