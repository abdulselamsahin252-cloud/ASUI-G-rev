package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.data.local.AppDatabase
import com.example.data.local.TaskEntity
import com.example.data.preferences.AppSettings
import com.example.data.preferences.ReminderTime
import java.util.Calendar

object ReminderScheduler {
    const val ACTION_PROGRESS_REMINDER = "com.example.ACTION_PROGRESS_REMINDER"
    const val ACTION_DEADLINE_CHECK = "com.example.ACTION_DEADLINE_CHECK"
    const val EXTRA_TASK_ID = "extra_task_id"

    private const val PROGRESS_ALARM_REQ_CODE = 4001

    fun scheduleAll(
        context: Context,
        settings: AppSettings,
        tasks: List<TaskEntity>
    ) {
        NotificationHelper.ensureChannels(context)
        scheduleNextProgressReminder(context, settings)
        scheduleTaskDeadlines(context, tasks)
    }

    fun scheduleNextProgressReminder(context: Context, settings: AppSettings) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ReminderAlarmReceiver::class.java).apply {
            action = ACTION_PROGRESS_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            PROGRESS_ALARM_REQ_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (!settings.remindersEnabled || settings.reminderDays.isEmpty() || settings.reminderTimes.isEmpty()) {
            alarmManager.cancel(pendingIntent)
            return
        }

        val nextTriggerMillis = computeNextReminderTrigger(
            daysIso = settings.reminderDays,
            times = settings.reminderTimes
        ) ?: return

        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            nextTriggerMillis,
            pendingIntent
        )
    }

    fun scheduleTaskDeadlines(context: Context, tasks: List<TaskEntity>) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = System.currentTimeMillis()

        tasks.forEach { task ->
            val deadline = task.deadlineAt
            val reqCode = (10_000L + task.id).toInt()
            val intent = Intent(context, ReminderAlarmReceiver::class.java).apply {
                action = ACTION_DEADLINE_CHECK
                putExtra(EXTRA_TASK_ID, task.id)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (deadline == null || task.isCompleted || task.deadlineNotified || deadline <= now) {
                alarmManager.cancel(pendingIntent)
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    deadline,
                    pendingIntent
                )
            }
        }
    }

    suspend fun checkAndNotifyExpiredDeadlines(context: Context) {
        val dao = AppDatabase.getInstance(context).taskDao()
        val now = System.currentTimeMillis()
        val tasks = dao.getAllTasksOnce()
        tasks.forEach { task ->
            val deadline = task.deadlineAt
            if (deadline != null && deadline <= now && !task.isCompleted && !task.deadlineNotified) {
                NotificationHelper.showDeadlineExpiredNotification(context, task)
                dao.markDeadlineNotified(task.id)
            }
        }
    }

    private fun computeNextReminderTrigger(
        daysIso: Set<Int>,
        times: List<ReminderTime>
    ): Long? {
        val now = Calendar.getInstance()
        var bestTrigger: Long? = null

        // Look ahead up to 8 days to find the earliest matching day + time in the future
        for (dayOffset in 0..8) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = now.timeInMillis
                add(Calendar.DAY_OF_YEAR, dayOffset)
            }
            val isoDay = calendarDayToIso(cal.get(Calendar.DAY_OF_WEEK))
            if (!daysIso.contains(isoDay)) continue

            for (t in times) {
                val candidate = (cal.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, t.hour)
                    set(Calendar.MINUTE, t.minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (candidate.timeInMillis > now.timeInMillis + 5_000L) {
                    if (bestTrigger == null || candidate.timeInMillis < bestTrigger) {
                        bestTrigger = candidate.timeInMillis
                    }
                }
            }
        }
        return bestTrigger
    }

    private fun calendarDayToIso(calendarDay: Int): Int = when (calendarDay) {
        Calendar.MONDAY -> 1
        Calendar.TUESDAY -> 2
        Calendar.WEDNESDAY -> 3
        Calendar.THURSDAY -> 4
        Calendar.FRIDAY -> 5
        Calendar.SATURDAY -> 6
        Calendar.SUNDAY -> 7
        else -> 1
    }
}
