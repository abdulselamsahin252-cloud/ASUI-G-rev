package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.data.preferences.WallpaperQuality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun WallpaperBackground(
    wallpaperPath: String?,
    blurRadius: Float,
    sharpness: Float,
    darkness: Float,
    quality: WallpaperQuality,
    modifier: Modifier = Modifier
) {
    val isApi31Plus = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val softwareBlurRadius = if (isApi31Plus) 0 else blurRadius.roundToInt().coerceIn(0, 25)

    val imageBitmap by produceState<ImageBitmap?>(
        initialValue = null,
        key1 = wallpaperPath,
        key2 = quality,
        key3 = softwareBlurRadius
    ) {
        value = if (wallpaperPath == null) {
            null
        } else {
            loadStyledBitmap(
                path = wallpaperPath,
                maxDimension = quality.maxDimension,
                softwareBlurRadius = softwareBlurRadius
            )?.asImageBitmap()
        }
    }

    val colorFilter = remember(sharpness) {
        buildClarityColorFilter(sharpness)
    }

    val filterQuality = when (quality) {
        WallpaperQuality.LOW -> FilterQuality.Low
        WallpaperQuality.MEDIUM -> FilterQuality.Medium
        WallpaperQuality.HIGH, WallpaperQuality.ORIGINAL -> FilterQuality.High
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (imageBitmap != null) {
            val imageModifier = if (isApi31Plus && blurRadius > 0.5f) {
                Modifier
                    .fillMaxSize()
                    .blur(
                        radius = blurRadius.dp,
                        edgeTreatment = BlurredEdgeTreatment.Rectangle
                    )
            } else {
                Modifier.fillMaxSize()
            }

            Image(
                bitmap = imageBitmap!!,
                contentDescription = null,
                modifier = imageModifier,
                contentScale = ContentScale.Crop,
                colorFilter = colorFilter,
                filterQuality = filterQuality
            )

            // Darkness / Blackness overlay
            if (darkness > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = darkness.coerceIn(0f, 0.92f)))
                )
            }
        }
    }
}

private fun buildClarityColorFilter(sharpness: Float): ColorFilter {
    // sharpness 0.2 .. 1.8 -> adjusts contrast & saturation smoothly
    val clamped = sharpness.coerceIn(0.2f, 1.8f)
    val contrast = 0.65f + (clamped * 0.35f) // ~0.72 to 1.28
    val translate = (-0.5f * contrast + 0.5f) * 255f
    val saturation = 0.55f + (clamped * 0.45f) // ~0.64 to 1.36

    val contrastMatrix = ColorMatrix(
        floatArrayOf(
            contrast, 0f, 0f, 0f, translate,
            0f, contrast, 0f, 0f, translate,
            0f, 0f, contrast, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        )
    )
    val satMatrix = ColorMatrix().apply { setToSaturation(saturation) }
    contrastMatrix.timesAssign(satMatrix)
    return ColorFilter.colorMatrix(contrastMatrix)
}

private suspend fun loadStyledBitmap(
    path: String,
    maxDimension: Int,
    softwareBlurRadius: Int
): Bitmap? = withContext(Dispatchers.IO) {
    runCatching {
        val file = File(path)
        if (!file.exists()) return@withContext null

        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, boundsOpts)

        val rawMax = max(boundsOpts.outWidth, boundsOpts.outHeight)
        var sampleSize = 1
        if (rawMax > maxDimension && maxDimension > 0) {
            while ((rawMax / (sampleSize * 2)) >= maxDimension) {
                sampleSize *= 2
            }
        }

        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeFile(path, decodeOpts) ?: return@withContext null

        if (softwareBlurRadius > 0) {
            val downscale = 4
            val smallW = (decoded.width / downscale).coerceAtLeast(32)
            val smallH = (decoded.height / downscale).coerceAtLeast(32)
            val scaled = Bitmap.createScaledBitmap(decoded, smallW, smallH, true)
            if (scaled !== decoded) decoded.recycle()
            fastBoxBlur(scaled, (softwareBlurRadius / 2).coerceIn(1, 12))
        } else {
            decoded
        }
    }.getOrNull()
}

private fun fastBoxBlur(bitmap: Bitmap, radius: Int): Bitmap {
    val w = bitmap.width
    val h = bitmap.height
    val pixels = IntArray(w * h)
    bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
    val out = IntArray(w * h)

    repeat(2) {
        // Horizontal pass
        for (y in 0 until h) {
            val rowOffset = y * w
            for (x in 0 until w) {
                var r = 0
                var g = 0
                var b = 0
                var count = 0
                val xStart = (x - radius).coerceAtLeast(0)
                val xEnd = (x + radius).coerceAtMost(w - 1)
                for (kx in xStart..xEnd) {
                    val p = pixels[rowOffset + kx]
                    r += (p ushr 16) and 0xFF
                    g += (p ushr 8) and 0xFF
                    b += p and 0xFF
                    count++
                }
                out[rowOffset + x] = (0xFF shl 24) or
                    ((r / count) shl 16) or
                    ((g / count) shl 8) or
                    (b / count)
            }
        }
        // Vertical pass
        for (x in 0 until w) {
            for (y in 0 until h) {
                var r = 0
                var g = 0
                var b = 0
                var count = 0
                val yStart = (y - radius).coerceAtLeast(0)
                val yEnd = (y + radius).coerceAtMost(h - 1)
                for (ky in yStart..yEnd) {
                    val p = out[ky * w + x]
                    r += (p ushr 16) and 0xFF
                    g += (p ushr 8) and 0xFF
                    b += p and 0xFF
                    count++
                }
                pixels[y * w + x] = (0xFF shl 24) or
                    ((r / count) shl 16) or
                    ((g / count) shl 8) or
                    (b / count)
            }
        }
    }

    val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    result.setPixels(pixels, 0, w, 0, 0, w, h)
    bitmap.recycle()
    return result
}
