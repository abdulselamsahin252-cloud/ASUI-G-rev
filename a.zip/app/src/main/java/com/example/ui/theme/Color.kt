package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 1. Sleek Light Palette (Crisp Pearl & Royal Indigo / Emerald)
val LightPrimary = Color(0xFF4338CA)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFE0E7FF)
val LightOnPrimaryContainer = Color(0xFF1E1B4B)

val LightSecondary = Color(0xFF0D9488)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFCCFBF1)
val LightOnSecondaryContainer = Color(0xFF064E3B)

val LightTertiary = Color(0xFFD97706)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFFEF3C7)
val LightOnTertiaryContainer = Color(0xFF451A03)

val LightBg = Color(0xFFF6F7FB)
val LightOnBg = Color(0xFF141824)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceLow = Color(0xFFF0F3FA)
val LightSurfaceVar = Color(0xFFE8ECF6)
val LightSurfaceHigh = Color(0xFFDDE3F0)
val LightOnSurfaceVar = Color(0xFF535B70)
val LightOutline = Color(0xFFCBD3E3)
val LightOutlineVar = Color(0xFFE2E7F2)

// 2. Sleek Dark Palette (Midnight Obsidian & Sky Cyan / Gold)
val DarkPrimary = Color(0xFF38BDF8)
val DarkOnPrimary = Color(0xFF062538)
val DarkPrimaryContainer = Color(0xFF0C3B59)
val DarkOnPrimaryContainer = Color(0xFFBAE6FD)

val DarkSecondary = Color(0xFF34D399)
val DarkOnSecondary = Color(0xFF042F22)
val DarkSecondaryContainer = Color(0xFF0D4736)
val DarkOnSecondaryContainer = Color(0xFFA7F3D0)

val DarkTertiary = Color(0xFFFBBF24)
val DarkOnTertiary = Color(0xFF382400)
val DarkTertiaryContainer = Color(0xFF543805)
val DarkOnTertiaryContainer = Color(0xFFFDE68A)

val DarkBg = Color(0xFF0D1117)
val DarkOnBg = Color(0xFFF0F4FA)
val DarkSurface = Color(0xFF151B24)
val DarkSurfaceLow = Color(0xFF11161E)
val DarkSurfaceVar = Color(0xFF1E2532)
val DarkSurfaceHigh = Color(0xFF283142)
val DarkOnSurfaceVar = Color(0xFFA3B0C6)
val DarkOutline = Color(0xFF333E52)
val DarkOutlineVar = Color(0xFF232B3A)

// 3. AMOLED Pure Black Palette (True #000000 OLED & Electric Mint / Gold)
val AmoledPrimary = Color(0xFF2DD4BF)
val AmoledOnPrimary = Color(0xFF00201C)
val AmoledPrimaryContainer = Color(0xFF093832)
val AmoledOnPrimaryContainer = Color(0xFF99F6E4)

val AmoledSecondary = Color(0xFF60A5FA)
val AmoledOnSecondary = Color(0xFF041D3D)
val AmoledSecondaryContainer = Color(0xFF0B2A52)
val AmoledOnSecondaryContainer = Color(0xFFBFDBFE)

val AmoledTertiary = Color(0xFFF59E0B)
val AmoledOnTertiary = Color(0xFF2D1B00)
val AmoledTertiaryContainer = Color(0xFF472C00)
val AmoledOnTertiaryContainer = Color(0xFFFDE68A)

val AmoledBg = Color(0xFF000000)
val AmoledOnBg = Color(0xFFF8FAFC)
val AmoledSurface = Color(0xFF050608)
val AmoledSurfaceLow = Color(0xFF030305)
val AmoledSurfaceVar = Color(0xFF101318)
val AmoledSurfaceHigh = Color(0xFF181C24)
val AmoledOnSurfaceVar = Color(0xFF9CA8BA)
val AmoledOutline = Color(0xFF272E3B)
val AmoledOutlineVar = Color(0xFF1A1F29)

// 4. Cyber Neon Palette (Deep Void Night & Electric Cyan / Hot Magenta / Laser Gold)
val NeonPrimary = Color(0xFF00F5D4)
val NeonOnPrimary = Color(0xFF00201B)
val NeonPrimaryContainer = Color(0xFF053D37)
val NeonOnPrimaryContainer = Color(0xFF7BFFEE)

val NeonSecondary = Color(0xFFFF2E93)
val NeonOnSecondary = Color(0xFFFFFFFF)
val NeonSecondaryContainer = Color(0xFF4D0A2B)
val NeonOnSecondaryContainer = Color(0xFFFFB3D6)

val NeonTertiary = Color(0xFFFFE600)
val NeonOnTertiary = Color(0xFF242000)
val NeonTertiaryContainer = Color(0xFF423B00)
val NeonOnTertiaryContainer = Color(0xFFFFF599)

val NeonBg = Color(0xFF070510)
val NeonOnBg = Color(0xFFF4F1FF)
val NeonSurface = Color(0xFF110D22)
val NeonSurfaceLow = Color(0xFF0C0919)
val NeonSurfaceVar = Color(0xFF1B1536)
val NeonSurfaceHigh = Color(0xFF251D4A)
val NeonOnSurfaceVar = Color(0xFFC2B7E8)
val NeonOutline = Color(0xFF4E3494)
val NeonOutlineVar = Color(0xFF332066)

// Semantic Status & Priority Accents
val SuccessGreen = Color(0xFF16A34A)
val SuccessGreenDark = Color(0xFF4ADE80)
val SuccessGreenNeon = Color(0xFF00F5D4)

val PriorityHighColor = Color(0xFFEF4444)
val PriorityHighDarkColor = Color(0xFFF87171)
val PriorityHighNeonColor = Color(0xFFFF2E93)

val PriorityMediumColor = Color(0xFFD97706)
val PriorityMediumDarkColor = Color(0xFFFBBF24)
val PriorityMediumNeonColor = Color(0xFFFFE600)

val PriorityLowColor = Color(0xFF0D9488)
val PriorityLowDarkColor = Color(0xFF38BDF8)
val PriorityLowNeonColor = Color(0xFF7C3AED)
