package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.preferences.AppThemeMode
import com.example.ui.theme.LocalAppThemeMode
import com.example.ui.theme.LocalHasWallpaper

@Composable
fun ProgressOverviewCard(
    totalCount: Int,
    completedCount: Int,
    activeCount: Int,
    averageProgress: Int,
    modifier: Modifier = Modifier
) {
    val themeMode = LocalAppThemeMode.current
    val hasWallpaper = LocalHasWallpaper.current

    val animatedPercent by animateIntAsState(
        targetValue = averageProgress.coerceIn(0, 100),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "avg_percent_int"
    )
    val animatedSweep by animateFloatAsState(
        targetValue = (averageProgress.coerceIn(0, 100) / 100f) * 360f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "avg_percent_sweep"
    )

    val subtitleText = when {
        totalCount == 0 -> stringResource(R.string.overview_empty_hint)
        completedCount == totalCount -> stringResource(R.string.overview_all_done)
        averageProgress >= 70 -> stringResource(R.string.overview_almost_there)
        else -> stringResource(R.string.overview_keep_going)
    }

    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val surface = MaterialTheme.colorScheme.surface
    val onSurface = MaterialTheme.colorScheme.onSurface

    val gradientColors = when (themeMode) {
        AppThemeMode.LIGHT -> listOf(
            primary,
            primary.copy(alpha = 0.90f),
            secondary.copy(alpha = 0.88f)
        )
        AppThemeMode.DARK -> listOf(
            surface.copy(alpha = if (hasWallpaper) 0.82f else 1f),
            primary.copy(alpha = 0.24f),
            secondary.copy(alpha = 0.18f)
        )
        AppThemeMode.AMOLED -> listOf(
            surface.copy(alpha = if (hasWallpaper) 0.78f else 0.98f),
            primary.copy(alpha = 0.16f),
            Color.Black.copy(alpha = 0.92f)
        )
        AppThemeMode.NEON -> listOf(
            surface.copy(alpha = if (hasWallpaper) 0.80f else 0.96f),
            primary.copy(alpha = 0.22f),
            secondary.copy(alpha = 0.24f)
        )
    }

    val cardTextColor = if (themeMode == AppThemeMode.LIGHT) Color.White else onSurface
    val arcTrackColor = if (themeMode == AppThemeMode.LIGHT) {
        Color.White.copy(alpha = 0.22f)
    } else {
        primary.copy(alpha = 0.20f)
    }
    val arcFillBrush = when (themeMode) {
        AppThemeMode.LIGHT -> Brush.sweepGradient(listOf(Color.White, MaterialTheme.colorScheme.tertiaryContainer))
        AppThemeMode.NEON -> Brush.sweepGradient(listOf(primary, secondary, tertiary, primary))
        else -> Brush.sweepGradient(listOf(primary, secondary, primary))
    }

    val borderStroke = when (themeMode) {
        AppThemeMode.NEON -> BorderStroke(
            width = 1.5.dp,
            brush = Brush.linearGradient(listOf(primary.copy(alpha = 0.8f), secondary.copy(alpha = 0.8f)))
        )
        AppThemeMode.AMOLED -> BorderStroke(1.dp, primary.copy(alpha = 0.35f))
        AppThemeMode.DARK -> BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
        AppThemeMode.LIGHT -> null
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("overview_card"),
        shape = MaterialTheme.shapes.large,
        tonalElevation = if (themeMode == AppThemeMode.AMOLED) 0.dp else 4.dp,
        shadowElevation = if (themeMode == AppThemeMode.LIGHT) 4.dp else 0.dp,
        border = borderStroke,
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = gradientColors,
                        start = Offset.Zero,
                        end = Offset(950f, 520f)
                    )
                )
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = stringResource(R.string.overview_title),
                        style = MaterialTheme.typography.labelLarge,
                        color = if (themeMode == AppThemeMode.LIGHT) {
                            cardTextColor.copy(alpha = 0.85f)
                        } else {
                            primary
                        }
                    )
                    Text(
                        text = if (totalCount == 0) {
                            stringResource(R.string.empty_title)
                        } else {
                            stringResource(
                                R.string.overview_completed_count,
                                completedCount,
                                totalCount
                            )
                        },
                        style = MaterialTheme.typography.headlineSmall,
                        color = cardTextColor
                    )
                    Text(
                        text = subtitleText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = cardTextColor.copy(alpha = 0.82f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val pillBg = if (themeMode == AppThemeMode.LIGHT) {
                            Color.White.copy(alpha = 0.18f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                        }
                        OverviewStatPill(
                            label = stringResource(R.string.stat_active),
                            value = activeCount.toString(),
                            containerColor = pillBg,
                            contentColor = cardTextColor
                        )
                        OverviewStatPill(
                            label = stringResource(R.string.stat_completed),
                            value = completedCount.toString(),
                            containerColor = pillBg,
                            contentColor = cardTextColor
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Box(
                    modifier = Modifier.size(96.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val strokeWidth = 10.dp.toPx()
                        val diameter = size.minDimension - strokeWidth
                        val topLeft = Offset(
                            (size.width - diameter) / 2f,
                            (size.height - diameter) / 2f
                        )
                        val arcSize = Size(diameter, diameter)

                        drawArc(
                            color = arcTrackColor,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )

                        if (animatedSweep > 0f) {
                            drawArc(
                                brush = arcFillBrush,
                                startAngle = -90f,
                                sweepAngle = animatedSweep,
                                useCenter = false,
                                topLeft = topLeft,
                                size = arcSize,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "%$animatedPercent",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            color = cardTextColor
                        )
                        Text(
                            text = stringResource(R.string.stat_average),
                            style = MaterialTheme.typography.labelSmall,
                            color = cardTextColor.copy(alpha = 0.78f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun OverviewStatPill(
    label: String,
    value: String,
    containerColor: Color,
    contentColor: Color
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(containerColor)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = contentColor
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = contentColor.copy(alpha = 0.88f)
        )
    }
}
