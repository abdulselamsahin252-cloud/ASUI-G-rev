package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.preferences.AppSettings
import com.example.data.preferences.CardDensity
import com.example.data.preferences.FabStyleMode
import com.example.data.preferences.HomeLayoutMode
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HomeCustomizeSheet(
    settings: AppSettings,
    onStepAmountChange: (Int) -> Unit,
    onLayoutModeChange: (HomeLayoutMode) -> Unit,
    onDensityChange: (CardDensity) -> Unit,
    onFabStyleChange: (FabStyleMode) -> Unit,
    onCornerRadiusChange: (Int) -> Unit,
    onCardOpacityChange: (Float) -> Unit,
    onShowOverviewChange: (Boolean) -> Unit,
    onShowStatusFiltersChange: (Boolean) -> Unit,
    onShowCategoryFiltersChange: (Boolean) -> Unit,
    onShowNotesChange: (Boolean) -> Unit,
    onShowBadgesChange: (Boolean) -> Unit,
    onShowDeadlinesChange: (Boolean) -> Unit,
    onResetHome: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var stepText by remember(settings.defaultStepAmount) {
        mutableStateOf(settings.defaultStepAmount.toString())
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .imePadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.settings_section_home_custom),
                    style = MaterialTheme.typography.headlineSmall
                )
                TextButton(
                    onClick = onResetHome,
                    modifier = Modifier.testTag("sheet_reset_home_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.custom_reset_home))
                }
            }

            // Default step increment
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.custom_step_default_title),
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = stringResource(R.string.custom_step_default_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(1, 5, 10, 15, 20, 25).forEach { preset ->
                        FilterChip(
                            selected = settings.defaultStepAmount == preset,
                            onClick = {
                                stepText = preset.toString()
                                onStepAmountChange(preset)
                            },
                            label = { Text("+$preset") },
                            modifier = Modifier.testTag("home_step_preset_$preset")
                        )
                    }
                }
                OutlinedTextField(
                    value = stepText,
                    onValueChange = { raw ->
                        val digits = raw.filter { it.isDigit() }.take(3)
                        stepText = digits
                        val parsed = digits.toIntOrNull()
                        if (parsed != null && parsed in 1..100) {
                            onStepAmountChange(parsed)
                        }
                    },
                    label = { Text(stringResource(R.string.step_custom_label)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_step_custom_input")
                )
            }

            // Layout mode
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.custom_layout_label),
                    style = MaterialTheme.typography.titleSmall
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    val modes = listOf(
                        HomeLayoutMode.AUTO to R.string.custom_layout_auto,
                        HomeLayoutMode.LIST to R.string.custom_layout_list,
                        HomeLayoutMode.GRID to R.string.custom_layout_grid
                    )
                    modes.forEachIndexed { index, (mode, labelRes) ->
                        SegmentedButton(
                            selected = settings.homeLayoutMode == mode,
                            onClick = { onLayoutModeChange(mode) },
                            shape = SegmentedButtonDefaults.itemShape(index, modes.size),
                            modifier = Modifier.testTag("layout_mode_${mode.name.lowercase()}")
                        ) {
                            Text(stringResource(labelRes), maxLines = 1)
                        }
                    }
                }
            }

            // Card density
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.custom_density_label),
                    style = MaterialTheme.typography.titleSmall
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    val densities = listOf(
                        CardDensity.COMFORTABLE to R.string.custom_density_comfortable,
                        CardDensity.COMPACT to R.string.custom_density_compact
                    )
                    densities.forEachIndexed { index, (density, labelRes) ->
                        SegmentedButton(
                            selected = settings.cardDensity == density,
                            onClick = { onDensityChange(density) },
                            shape = SegmentedButtonDefaults.itemShape(index, densities.size)
                        ) {
                            Text(stringResource(labelRes), maxLines = 1)
                        }
                    }
                }
            }

            // FAB style
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.custom_fab_style_label),
                    style = MaterialTheme.typography.titleSmall
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    val styles = listOf(
                        FabStyleMode.EXTENDED to R.string.custom_fab_extended,
                        FabStyleMode.COMPACT_ICON to R.string.custom_fab_compact,
                        FabStyleMode.CENTER_EXTENDED to R.string.custom_fab_center
                    )
                    styles.forEachIndexed { index, (style, labelRes) ->
                        SegmentedButton(
                            selected = settings.fabStyleMode == style,
                            onClick = { onFabStyleChange(style) },
                            shape = SegmentedButtonDefaults.itemShape(index, styles.size)
                        ) {
                            Text(stringResource(labelRes), maxLines = 1)
                        }
                    }
                }
            }

            // Corner radius & Opacity
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.custom_corner_radius),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "${settings.cardCornerRadius} dp",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = settings.cardCornerRadius.toFloat(),
                    onValueChange = { onCornerRadiusChange(it.roundToInt()) },
                    valueRange = 8f..28f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.custom_card_opacity),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "%${(settings.cardOpacity * 100f).roundToInt()}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Slider(
                    value = settings.cardOpacity,
                    onValueChange = onCardOpacityChange,
                    valueRange = 0.40f..1.0f
                )
            }

            // Visibility toggles
            ToggleRow(
                label = stringResource(R.string.custom_show_overview),
                checked = settings.showOverviewCard,
                onCheckedChange = onShowOverviewChange
            )
            ToggleRow(
                label = stringResource(R.string.custom_show_status_filters),
                checked = settings.showStatusFilters,
                onCheckedChange = onShowStatusFiltersChange
            )
            ToggleRow(
                label = stringResource(R.string.custom_show_category_filters),
                checked = settings.showCategoryFilters,
                onCheckedChange = onShowCategoryFiltersChange
            )
            ToggleRow(
                label = stringResource(R.string.custom_show_notes),
                checked = settings.showNotesOnCards,
                onCheckedChange = onShowNotesChange
            )
            ToggleRow(
                label = stringResource(R.string.custom_show_badges),
                checked = settings.showBadgesOnCards,
                onCheckedChange = onShowBadgesChange
            )
            ToggleRow(
                label = stringResource(R.string.custom_show_deadlines),
                checked = settings.showDeadlinesOnCards,
                onCheckedChange = onShowDeadlinesChange
            )

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
