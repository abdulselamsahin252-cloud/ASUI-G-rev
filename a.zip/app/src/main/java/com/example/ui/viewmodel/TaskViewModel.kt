package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProgressMode
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import com.example.data.repository.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class StatusFilter {
    ALL,
    ACTIVE,
    COMPLETED
}

enum class SortOrder {
    NEWEST,
    PROGRESS_DESC,
    PROGRESS_ASC,
    PRIORITY
}

data class TaskUiState(
    val visibleTasks: List<TaskEntity> = emptyList(),
    val totalCount: Int = 0,
    val completedCount: Int = 0,
    val activeCount: Int = 0,
    val averageProgress: Int = 0,
    val searchQuery: String = "",
    val statusFilter: StatusFilter = StatusFilter.ALL,
    val selectedCategory: TaskCategory? = null,
    val sortOrder: SortOrder = SortOrder.NEWEST,
    val hasLoaded: Boolean = false
)

private data class FilterParams(
    val searchQuery: String = "",
    val statusFilter: StatusFilter = StatusFilter.ALL,
    val selectedCategory: TaskCategory? = null,
    val sortOrder: SortOrder = SortOrder.NEWEST
)

class TaskViewModel(
    private val repository: TaskRepository
) : ViewModel() {

    private val filterParams = MutableStateFlow(FilterParams())
    private var lastDeletedTask: TaskEntity? = null

    val uiState: StateFlow<TaskUiState> = combine(
        repository.allTasks,
        filterParams
    ) { allTasks, params ->
        val completedCount = allTasks.count { it.isCompleted }
        val activeCount = allTasks.size - completedCount
        val avgProgress = if (allTasks.isEmpty()) 0 else {
            allTasks.map { it.effectivePercent }.average().roundToInt()
        }

        val query = params.searchQuery.trim()
        val filtered = allTasks.filter { task ->
            val matchesQuery = query.isEmpty() ||
                task.title.contains(query, ignoreCase = true) ||
                task.note.contains(query, ignoreCase = true) ||
                task.unitLabel.contains(query, ignoreCase = true)

            val matchesStatus = when (params.statusFilter) {
                StatusFilter.ALL -> true
                StatusFilter.ACTIVE -> !task.isCompleted
                StatusFilter.COMPLETED -> task.isCompleted
            }

            val matchesCategory = params.selectedCategory == null ||
                task.category == params.selectedCategory

            matchesQuery && matchesStatus && matchesCategory
        }

        val sorted = when (params.sortOrder) {
            SortOrder.NEWEST -> filtered.sortedByDescending { it.createdAt }
            SortOrder.PROGRESS_DESC -> filtered.sortedWith(
                compareByDescending<TaskEntity> { it.effectivePercent }
                    .thenByDescending { it.createdAt }
            )
            SortOrder.PROGRESS_ASC -> filtered.sortedWith(
                compareBy<TaskEntity> { it.effectivePercent }
                    .thenByDescending { it.createdAt }
            )
            SortOrder.PRIORITY -> filtered.sortedWith(
                compareBy<TaskEntity> { it.isCompleted }
                    .thenByDescending { it.priority.weight }
                    .thenByDescending { it.createdAt }
            )
        }

        TaskUiState(
            visibleTasks = sorted,
            totalCount = allTasks.size,
            completedCount = completedCount,
            activeCount = activeCount,
            averageProgress = avgProgress,
            searchQuery = params.searchQuery,
            statusFilter = params.statusFilter,
            selectedCategory = params.selectedCategory,
            sortOrder = params.sortOrder,
            hasLoaded = true
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TaskUiState()
    )

    fun updateSearchQuery(query: String) {
        filterParams.value = filterParams.value.copy(searchQuery = query)
    }

    fun setStatusFilter(filter: StatusFilter) {
        filterParams.value = filterParams.value.copy(statusFilter = filter)
    }

    fun setCategoryFilter(category: TaskCategory?) {
        val current = filterParams.value.selectedCategory
        filterParams.value = filterParams.value.copy(
            selectedCategory = if (current == category) null else category
        )
    }

    fun setSortOrder(order: SortOrder) {
        filterParams.value = filterParams.value.copy(sortOrder = order)
    }

    fun resetFilters() {
        filterParams.value = FilterParams(sortOrder = filterParams.value.sortOrder)
    }

    fun saveTask(
        existingTask: TaskEntity?,
        title: String,
        note: String,
        category: TaskCategory,
        priority: TaskPriority,
        progressMode: ProgressMode,
        progressPercent: Int,
        completedAmount: Int,
        targetAmount: Int,
        unitLabel: String
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isEmpty()) return

        val safeTarget = targetAmount.coerceAtLeast(1)
        val safeCompleted = completedAmount.coerceIn(0, safeTarget)
        val safePercent = progressPercent.coerceIn(0, 100)

        val entity = if (existingTask != null) {
            existingTask.copy(
                title = cleanTitle,
                note = note.trim(),
                category = category,
                priority = priority,
                progressMode = progressMode,
                progressPercent = safePercent,
                completedAmount = safeCompleted,
                targetAmount = safeTarget,
                unitLabel = unitLabel.trim(),
                lastNonFullPercent = if (safePercent < 100) safePercent else existingTask.lastNonFullPercent,
                lastNonFullAmount = if (safeCompleted < safeTarget) safeCompleted else existingTask.lastNonFullAmount
            )
        } else {
            TaskEntity(
                title = cleanTitle,
                note = note.trim(),
                category = category,
                priority = priority,
                progressMode = progressMode,
                progressPercent = safePercent,
                completedAmount = safeCompleted,
                targetAmount = safeTarget,
                unitLabel = unitLabel.trim(),
                lastNonFullPercent = if (safePercent < 100) safePercent else 0,
                lastNonFullAmount = if (safeCompleted < safeTarget) safeCompleted else 0
            )
        }

        viewModelScope.launch {
            repository.upsertTask(entity)
        }
    }

    fun updateTaskProgress(
        task: TaskEntity,
        mode: ProgressMode,
        newPercent: Int,
        newCompletedAmount: Int,
        newTargetAmount: Int
    ) {
        val safeTarget = newTargetAmount.coerceAtLeast(1)
        val safeCompleted = newCompletedAmount.coerceIn(0, safeTarget)
        val safePercent = newPercent.coerceIn(0, 100)

        val updated = task.copy(
            progressMode = mode,
            progressPercent = safePercent,
            completedAmount = safeCompleted,
            targetAmount = safeTarget,
            lastNonFullPercent = if (safePercent < 100) safePercent else task.lastNonFullPercent,
            lastNonFullAmount = if (safeCompleted < safeTarget) safeCompleted else task.lastNonFullAmount
        )

        viewModelScope.launch {
            repository.upsertTask(updated)
        }
    }

    fun stepProgress(task: TaskEntity, delta: Int) {
        val updated = when (task.progressMode) {
            ProgressMode.PERCENTAGE -> {
                val next = (task.progressPercent + delta * 10).coerceIn(0, 100)
                task.copy(
                    progressPercent = next,
                    lastNonFullPercent = if (next < 100) next else task.lastNonFullPercent
                )
            }
            ProgressMode.AMOUNT -> {
                val safeTarget = task.targetAmount.coerceAtLeast(1)
                val next = (task.completedAmount + delta).coerceIn(0, safeTarget)
                task.copy(
                    completedAmount = next,
                    lastNonFullAmount = if (next < safeTarget) next else task.lastNonFullAmount
                )
            }
        }
        viewModelScope.launch {
            repository.upsertTask(updated)
        }
    }

    fun toggleTaskCompleted(task: TaskEntity) {
        val updated = if (task.isCompleted) {
            when (task.progressMode) {
                ProgressMode.PERCENTAGE -> {
                    val restore = if (task.lastNonFullPercent in 0..99) task.lastNonFullPercent else 0
                    task.copy(progressPercent = restore)
                }
                ProgressMode.AMOUNT -> {
                    val safeTarget = task.targetAmount.coerceAtLeast(1)
                    val restore = if (task.lastNonFullAmount in 0 until safeTarget) task.lastNonFullAmount else 0
                    task.copy(completedAmount = restore)
                }
            }
        } else {
            when (task.progressMode) {
                ProgressMode.PERCENTAGE -> task.copy(
                    lastNonFullPercent = task.progressPercent.coerceIn(0, 99),
                    progressPercent = 100
                )
                ProgressMode.AMOUNT -> {
                    val safeTarget = task.targetAmount.coerceAtLeast(1)
                    task.copy(
                        lastNonFullAmount = task.completedAmount.coerceIn(0, safeTarget - 1),
                        completedAmount = safeTarget
                    )
                }
            }
        }
        viewModelScope.launch {
            repository.upsertTask(updated)
        }
    }

    fun deleteTask(task: TaskEntity) {
        lastDeletedTask = task
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun undoLastDelete() {
        val task = lastDeletedTask ?: return
        lastDeletedTask = null
        viewModelScope.launch {
            repository.restoreTask(task)
        }
    }

    fun clearCompleted() {
        viewModelScope.launch {
            repository.clearCompleted()
        }
    }
}

class TaskViewModelFactory(
    private val repository: TaskRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TaskViewModel::class.java)) {
            return TaskViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
