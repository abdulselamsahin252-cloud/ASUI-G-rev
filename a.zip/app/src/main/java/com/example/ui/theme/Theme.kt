package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AppThemeMode

val LocalAppThemeMode = staticCompositionLocalOf { AppThemeMode.DARK }
val LocalHasWallpaper = staticCompositionLocalOf { false }

private val LightScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,
    background = LightBg,
    onBackground = LightOnBg,
    surface = LightSurface,
    onSurface = LightOnBg,
    surfaceVariant = LightSurfaceVar,
    onSurfaceVariant = LightOnSurfaceVar,
    surfaceContainerLowest = LightSurface,
    surfaceContainerLow = LightSurfaceLow,
    surfaceContainer = LightSurfaceVar,
    surfaceContainerHigh = LightSurfaceHigh,
    outline = LightOutline,
    outlineVariant = LightOutlineVar
)

private val DarkScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    tertiaryContainer = DarkTertiaryContainer,
    onTertiaryContainer = DarkOnTertiaryContainer,
    background = DarkBg,
    onBackground = DarkOnBg,
    surface = DarkSurface,
    onSurface = DarkOnBg,
    surfaceVariant = DarkSurfaceVar,
    onSurfaceVariant = DarkOnSurfaceVar,
    surfaceContainerLowest = DarkBg,
    surfaceContainerLow = DarkSurfaceLow,
    surfaceContainer = DarkSurfaceVar,
    surfaceContainerHigh = DarkSurfaceHigh,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVar
)

private val AmoledScheme = darkColorScheme(
    primary = AmoledPrimary,
    onPrimary = AmoledOnPrimary,
    primaryContainer = AmoledPrimaryContainer,
    onPrimaryContainer = AmoledOnPrimaryContainer,
    secondary = AmoledSecondary,
    onSecondary = AmoledOnSecondary,
    secondaryContainer = AmoledSecondaryContainer,
    onSecondaryContainer = AmoledOnSecondaryContainer,
    tertiary = AmoledTertiary,
    onTertiary = AmoledOnTertiary,
    tertiaryContainer = AmoledTertiaryContainer,
    onTertiaryContainer = AmoledOnTertiaryContainer,
    background = AmoledBg,
    onBackground = AmoledOnBg,
    surface = AmoledSurface,
    onSurface = AmoledOnBg,
    surfaceVariant = AmoledSurfaceVar,
    onSurfaceVariant = AmoledOnSurfaceVar,
    surfaceContainerLowest = AmoledBg,
    surfaceContainerLow = AmoledSurfaceLow,
    surfaceContainer = AmoledSurfaceVar,
    surfaceContainerHigh = AmoledSurfaceHigh,
    outline = AmoledOutline,
    outlineVariant = AmoledOutlineVar
)

private val NeonScheme = darkColorScheme(
    primary = NeonPrimary,
    onPrimary = NeonOnPrimary,
    primaryContainer = NeonPrimaryContainer,
    onPrimaryContainer = NeonOnPrimaryContainer,
    secondary = NeonSecondary,
    onSecondary = NeonOnSecondary,
    secondaryContainer = NeonSecondaryContainer,
    onSecondaryContainer = NeonOnSecondaryContainer,
    tertiary = NeonTertiary,
    onTertiary = NeonOnTertiary,
    tertiaryContainer = NeonTertiaryContainer,
    onTertiaryContainer = NeonOnTertiaryContainer,
    background = NeonBg,
    onBackground = NeonOnBg,
    surface = NeonSurface,
    onSurface = NeonOnBg,
    surfaceVariant = NeonSurfaceVar,
    onSurfaceVariant = NeonOnSurfaceVar,
    surfaceContainerLowest = NeonBg,
    surfaceContainerLow = NeonSurfaceLow,
    surfaceContainer = NeonSurfaceVar,
    surfaceContainerHigh = NeonSurfaceHigh,
    outline = NeonOutline,
    outlineVariant = NeonOutlineVar
)

val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun AdimAdimTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    hasWallpaper: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.LIGHT -> LightScheme
        AppThemeMode.DARK -> DarkScheme
        AppThemeMode.AMOLED -> AmoledScheme
        AppThemeMode.NEON -> NeonScheme
    }

    CompositionLocalProvider(
        LocalAppThemeMode provides themeMode,
        LocalHasWallpaper provides hasWallpaper
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}
