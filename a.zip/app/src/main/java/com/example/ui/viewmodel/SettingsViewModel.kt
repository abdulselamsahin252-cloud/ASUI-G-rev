package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppSettings
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.SettingsRepository
import com.example.data.preferences.WallpaperQuality
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun setLanguage(language: AppLanguage, onApplied: () -> Unit = {}) {
        viewModelScope.launch {
            repository.setLanguage(language)
            onApplied()
        }
    }

    fun saveWallpaper(uri: Uri) {
        viewModelScope.launch { repository.saveWallpaperFromUri(uri) }
    }

    fun clearWallpaper() {
        viewModelScope.launch { repository.clearWallpaper() }
    }

    fun setWallpaperBlur(blur: Float) {
        viewModelScope.launch { repository.setWallpaperBlur(blur) }
    }

    fun setWallpaperSharpness(sharpness: Float) {
        viewModelScope.launch { repository.setWallpaperSharpness(sharpness) }
    }

    fun setWallpaperDarkness(darkness: Float) {
        viewModelScope.launch { repository.setWallpaperDarkness(darkness) }
    }

    fun setWallpaperQuality(quality: WallpaperQuality) {
        viewModelScope.launch { repository.setWallpaperQuality(quality) }
    }

    fun resetWallpaperAdjustments() {
        viewModelScope.launch { repository.resetWallpaperAdjustments() }
    }
}

class SettingsViewModelFactory(
    private val repository: SettingsRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
            return SettingsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
