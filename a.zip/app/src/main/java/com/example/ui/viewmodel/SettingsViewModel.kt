package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppSettings
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.CardDensity
import com.example.data.preferences.FabStyleMode
import com.example.data.preferences.HomeLayoutMode
import com.example.data.preferences.ReminderTime
import com.example.data.preferences.SettingsRepository
import com.example.data.preferences.WallpaperQuality
import com.example.data.preferences.WidgetStyleMode
import com.example.notifications.NotificationHelper
import com.example.notifications.ReminderScheduler
import com.example.widgets.WidgetUpdater
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val appContext: Context,
    private val repository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch {
            repository.setThemeMode(mode)
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    fun setLanguage(language: AppLanguage, onApplied: () -> Unit = {}) {
        viewModelScope.launch {
            repository.setLanguage(language)
            WidgetUpdater.updateAllSync(appContext)
            onApplied()
        }
    }

    // App Wallpaper
    fun saveWallpaper(uri: Uri) {
        viewModelScope.launch { repository.saveWallpaperFromUri(uri) }
    }

    fun clearWallpaper() {
        viewModelScope.launch { repository.clearWallpaper() }
    }

    fun setWallpaperBlur(blur: Float) {
        viewModelScope.launch { repository.setWallpaperBlur(blur) }
    }

    fun setWallpaperSharpness(sharpness: Float) {
        viewModelScope.launch { repository.setWallpaperSharpness(sharpness) }
    }

    fun setWallpaperDarkness(darkness: Float) {
        viewModelScope.launch { repository.setWallpaperDarkness(darkness) }
    }

    fun setWallpaperQuality(quality: WallpaperQuality) {
        viewModelScope.launch { repository.setWallpaperQuality(quality) }
    }

    fun resetWallpaperAdjustments() {
        viewModelScope.launch { repository.resetWallpaperAdjustments() }
    }

    // Home Customization
    fun setDefaultStepAmount(step: Int) {
        viewModelScope.launch {
            repository.setDefaultStepAmount(step)
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    fun setHomeLayoutMode(mode: HomeLayoutMode) {
        viewModelScope.launch { repository.setHomeLayoutMode(mode) }
    }

    fun setCardDensity(density: CardDensity) {
        viewModelScope.launch { repository.setCardDensity(density) }
    }

    fun setFabStyleMode(mode: FabStyleMode) {
        viewModelScope.launch { repository.setFabStyleMode(mode) }
    }

    fun setCardCornerRadius(radius: Int) {
        viewModelScope.launch { repository.setCardCornerRadius(radius) }
    }

    fun setCardOpacity(opacity: Float) {
        viewModelScope.launch { repository.setCardOpacity(opacity) }
    }

    fun setShowOverviewCard(show: Boolean) {
        viewModelScope.launch { repository.setShowOverviewCard(show) }
    }

    fun setShowStatusFilters(show: Boolean) {
        viewModelScope.launch { repository.setShowStatusFilters(show) }
    }

    fun setShowCategoryFilters(show: Boolean) {
        viewModelScope.launch { repository.setShowCategoryFilters(show) }
    }

    fun setShowNotesOnCards(show: Boolean) {
        viewModelScope.launch { repository.setShowNotesOnCards(show) }
    }

    fun setShowBadgesOnCards(show: Boolean) {
        viewModelScope.launch { repository.setShowBadgesOnCards(show) }
    }

    fun setShowDeadlinesOnCards(show: Boolean) {
        viewModelScope.launch { repository.setShowDeadlinesOnCards(show) }
    }

    fun resetHomeCustomization() {
        viewModelScope.launch {
            repository.resetHomeCustomization()
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    // Widget Customization
    fun saveWidgetWallpaper(uri: Uri) {
        viewModelScope.launch {
            repository.saveWidgetWallpaperFromUri(uri)
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    fun clearWidgetWallpaper() {
        viewModelScope.launch {
            repository.clearWidgetWallpaper()
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    fun setWidgetBlur(blur: Float) {
        viewModelScope.launch {
            repository.setWidgetBlur(blur)
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    fun setWidgetSharpness(sharpness: Float) {
        viewModelScope.launch {
            repository.setWidgetSharpness(sharpness)
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    fun setWidgetDarkness(darkness: Float) {
        viewModelScope.launch {
            repository.setWidgetDarkness(darkness)
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    fun setWidgetStyleMode(style: WidgetStyleMode) {
        viewModelScope.launch {
            repository.setWidgetStyleMode(style)
            WidgetUpdater.updateAllSync(appContext)
        }
    }

    // Reminder Schedule
    fun setRemindersEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.setRemindersEnabled(enabled)
            val updated = repository.getSettingsOnce()
            ReminderScheduler.scheduleNextProgressReminder(appContext, updated)
        }
    }

    fun toggleReminderDay(dayIso: Int) {
        viewModelScope.launch {
            repository.toggleReminderDay(dayIso)
            val updated = repository.getSettingsOnce()
            ReminderScheduler.scheduleNextProgressReminder(appContext, updated)
        }
    }

    fun addReminderTime(time: ReminderTime) {
        viewModelScope.launch {
            repository.addReminderTime(time)
            val updated = repository.getSettingsOnce()
            ReminderScheduler.scheduleNextProgressReminder(appContext, updated)
        }
    }

    fun removeReminderTime(time: ReminderTime) {
        viewModelScope.launch {
            repository.removeReminderTime(time)
            val updated = repository.getSettingsOnce()
            ReminderScheduler.scheduleNextProgressReminder(appContext, updated)
        }
    }

    fun sendTestNotification() {
        viewModelScope.launch {
            val tasks = AppDatabase.getInstance(appContext).taskDao().getAllTasksOnce()
            NotificationHelper.showProgressReminderNotification(appContext, tasks)
        }
    }
}

class SettingsViewModelFactory(
    private val appContext: Context,
    private val repository: SettingsRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
            return SettingsViewModel(appContext.applicationContext, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
