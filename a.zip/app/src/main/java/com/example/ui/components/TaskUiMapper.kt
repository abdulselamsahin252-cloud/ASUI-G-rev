package com.example.ui.components

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PersonOutline
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.WorkOutline
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.R
import com.example.data.local.TaskCategory
import com.example.data.local.TaskPriority
import com.example.data.preferences.AppThemeMode
import com.example.ui.theme.LocalAppThemeMode
import com.example.ui.theme.PriorityHighColor
import com.example.ui.theme.PriorityHighDarkColor
import com.example.ui.theme.PriorityHighNeonColor
import com.example.ui.theme.PriorityLowColor
import com.example.ui.theme.PriorityLowDarkColor
import com.example.ui.theme.PriorityLowNeonColor
import com.example.ui.theme.PriorityMediumColor
import com.example.ui.theme.PriorityMediumDarkColor
import com.example.ui.theme.PriorityMediumNeonColor
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenDark
import com.example.ui.theme.SuccessGreenNeon

@StringRes
fun TaskCategory.labelRes(): Int = when (this) {
    TaskCategory.GENEL -> R.string.category_genel
    TaskCategory.IS -> R.string.category_is
    TaskCategory.KISISEL -> R.string.category_kisisel
    TaskCategory.EGITIM -> R.string.category_egitim
    TaskCategory.SAGLIK -> R.string.category_saglik
    TaskCategory.ALISVERIS -> R.string.category_alisveris
}

fun TaskCategory.icon(): ImageVector = when (this) {
    TaskCategory.GENEL -> Icons.Rounded.Checklist
    TaskCategory.IS -> Icons.Rounded.WorkOutline
    TaskCategory.KISISEL -> Icons.Rounded.PersonOutline
    TaskCategory.EGITIM -> Icons.Rounded.AutoStories
    TaskCategory.SAGLIK -> Icons.Rounded.FavoriteBorder
    TaskCategory.ALISVERIS -> Icons.Rounded.ShoppingBag
}

@StringRes
fun TaskPriority.labelRes(): Int = when (this) {
    TaskPriority.DUSUK -> R.string.priority_low
    TaskPriority.ORTA -> R.string.priority_medium
    TaskPriority.YUKSEK -> R.string.priority_high
}

@Composable
fun TaskPriority.accentColor(): Color {
    return when (LocalAppThemeMode.current) {
        AppThemeMode.LIGHT -> when (this) {
            TaskPriority.DUSUK -> PriorityLowColor
            TaskPriority.ORTA -> PriorityMediumColor
            TaskPriority.YUKSEK -> PriorityHighColor
        }
        AppThemeMode.DARK, AppThemeMode.AMOLED -> when (this) {
            TaskPriority.DUSUK -> PriorityLowDarkColor
            TaskPriority.ORTA -> PriorityMediumDarkColor
            TaskPriority.YUKSEK -> PriorityHighDarkColor
        }
        AppThemeMode.NEON -> when (this) {
            TaskPriority.DUSUK -> PriorityLowNeonColor
            TaskPriority.ORTA -> PriorityMediumNeonColor
            TaskPriority.YUKSEK -> PriorityHighNeonColor
        }
    }
}

@Composable
fun themeSuccessColor(): Color {
    return when (LocalAppThemeMode.current) {
        AppThemeMode.LIGHT -> SuccessGreen
        AppThemeMode.DARK, AppThemeMode.AMOLED -> SuccessGreenDark
        AppThemeMode.NEON -> SuccessGreenNeon
    }
}

@Composable
fun TaskCategory.containerColor(): Color = when (this) {
    TaskCategory.GENEL -> MaterialTheme.colorScheme.surfaceVariant
    TaskCategory.IS -> MaterialTheme.colorScheme.primaryContainer
    TaskCategory.KISISEL -> MaterialTheme.colorScheme.secondaryContainer
    TaskCategory.EGITIM -> MaterialTheme.colorScheme.tertiaryContainer
    TaskCategory.SAGLIK -> MaterialTheme.colorScheme.secondaryContainer
    TaskCategory.ALISVERIS -> MaterialTheme.colorScheme.primaryContainer
}

@Composable
fun TaskCategory.contentColor(): Color = when (this) {
    TaskCategory.GENEL -> MaterialTheme.colorScheme.onSurfaceVariant
    TaskCategory.IS -> MaterialTheme.colorScheme.onPrimaryContainer
    TaskCategory.KISISEL -> MaterialTheme.colorScheme.onSecondaryContainer
    TaskCategory.EGITIM -> MaterialTheme.colorScheme.onTertiaryContainer
    TaskCategory.SAGLIK -> MaterialTheme.colorScheme.onSecondaryContainer
    TaskCategory.ALISVERIS -> MaterialTheme.colorScheme.onPrimaryContainer
}
