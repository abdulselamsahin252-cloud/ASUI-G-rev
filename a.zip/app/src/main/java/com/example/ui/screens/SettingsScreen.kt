package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppSettings
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.WallpaperQuality
import com.example.ui.components.WallpaperBackground
import com.example.ui.theme.AmoledBg
import com.example.ui.theme.AmoledPrimary
import com.example.ui.theme.AmoledSecondary
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSecondary
import com.example.ui.theme.LightBg
import com.example.ui.theme.LightPrimary
import com.example.ui.theme.LightSecondary
import com.example.ui.theme.LocalHasWallpaper
import com.example.ui.theme.NeonBg
import com.example.ui.theme.NeonPrimary
import com.example.ui.theme.NeonSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSelectTheme: (AppThemeMode) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onPickWallpaper: (android.net.Uri) -> Unit,
    onClearWallpaper: () -> Unit,
    onBlurChange: (Float) -> Unit,
    onSharpnessChange: (Float) -> Unit,
    onDarknessChange: (Float) -> Unit,
    onQualityChange: (WallpaperQuality) -> Unit,
    onResetWallpaperAdjustments: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val hasWallpaper = LocalHasWallpaper.current
    val cardAlpha = if (hasWallpaper) 0.84f else 1f

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickWallpaper(uri)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                title = {
                    Text(
                        text = stringResource(R.string.settings_title),
                        style = MaterialTheme.typography.headlineSmall
                    )
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Theme Selection Section
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Palette,
                        title = stringResource(R.string.settings_section_theme),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_light),
                                    subtitle = stringResource(R.string.settings_theme_light_desc),
                                    bgPreview = LightBg,
                                    accent1 = LightPrimary,
                                    accent2 = LightSecondary,
                                    selected = settings.themeMode == AppThemeMode.LIGHT,
                                    onClick = { onSelectTheme(AppThemeMode.LIGHT) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_light_option")
                                )
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_dark),
                                    subtitle = stringResource(R.string.settings_theme_dark_desc),
                                    bgPreview = DarkBg,
                                    accent1 = DarkPrimary,
                                    accent2 = DarkSecondary,
                                    selected = settings.themeMode == AppThemeMode.DARK,
                                    onClick = { onSelectTheme(AppThemeMode.DARK) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_dark_option")
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_amoled),
                                    subtitle = stringResource(R.string.settings_theme_amoled_desc),
                                    bgPreview = AmoledBg,
                                    accent1 = AmoledPrimary,
                                    accent2 = AmoledSecondary,
                                    selected = settings.themeMode == AppThemeMode.AMOLED,
                                    onClick = { onSelectTheme(AppThemeMode.AMOLED) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_amoled_option")
                                )
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_neon),
                                    subtitle = stringResource(R.string.settings_theme_neon_desc),
                                    bgPreview = NeonBg,
                                    accent1 = NeonPrimary,
                                    accent2 = NeonSecondary,
                                    selected = settings.themeMode == AppThemeMode.NEON,
                                    onClick = { onSelectTheme(AppThemeMode.NEON) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_neon_option")
                                )
                            }
                        }
                    }
                }

                // 2. Custom Wallpaper Section
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Image,
                        title = stringResource(R.string.settings_section_wallpaper),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            if (settings.wallpaperPath == null) {
                                Text(
                                    text = stringResource(R.string.settings_wallpaper_none),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                // Live preview thumbnail inside card
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(150.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .border(
                                            1.dp,
                                            MaterialTheme.colorScheme.outline,
                                            RoundedCornerShape(16.dp)
                                        )
                                ) {
                                    WallpaperBackground(
                                        wallpaperPath = settings.wallpaperPath,
                                        blurRadius = settings.wallpaperBlur,
                                        sharpness = settings.wallpaperSharpness,
                                        darkness = settings.wallpaperDarkness,
                                        quality = settings.wallpaperQuality
                                    )
                                    Surface(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(10.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)
                                    ) {
                                        Text(
                                            text = stringResource(R.string.cd_wallpaper_preview),
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("pick_wallpaper_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Image,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(
                                            if (settings.wallpaperPath == null) R.string.settings_wallpaper_pick
                                            else R.string.settings_wallpaper_change
                                        )
                                    )
                                }

                                if (settings.wallpaperPath != null) {
                                    OutlinedButton(
                                        onClick = onClearWallpaper,
                                        modifier = Modifier.testTag("remove_wallpaper_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.DeleteOutline,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(stringResource(R.string.settings_wallpaper_remove))
                                    }
                                }
                            }

                            if (settings.wallpaperPath != null) {
                                WallpaperSliderRow(
                                    label = stringResource(R.string.settings_wallpaper_blur),
                                    valueText = "${settings.wallpaperBlur.roundToInt()} dp",
                                    value = settings.wallpaperBlur,
                                    valueRange = 0f..30f,
                                    onValueChange = onBlurChange,
                                    testTag = "wallpaper_blur_slider"
                                )

                                WallpaperSliderRow(
                                    label = stringResource(R.string.settings_wallpaper_sharpness),
                                    valueText = "%${(settings.wallpaperSharpness * 100f).roundToInt()}",
                                    value = settings.wallpaperSharpness,
                                    valueRange = 0.2f..1.8f,
                                    onValueChange = onSharpnessChange,
                                    testTag = "wallpaper_sharpness_slider"
                                )

                                WallpaperSliderRow(
                                    label = stringResource(R.string.settings_wallpaper_darkness),
                                    valueText = "%${(settings.wallpaperDarkness * 100f).roundToInt()}",
                                    value = settings.wallpaperDarkness,
                                    valueRange = 0f..0.92f,
                                    onValueChange = onDarknessChange,
                                    testTag = "wallpaper_darkness_slider"
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = stringResource(R.string.settings_wallpaper_quality),
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    SingleChoiceSegmentedButtonRow(
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        WallpaperQuality.entries.forEachIndexed { idx, quality ->
                                            val labelRes = when (quality) {
                                                WallpaperQuality.LOW -> R.string.settings_quality_low
                                                WallpaperQuality.MEDIUM -> R.string.settings_quality_medium
                                                WallpaperQuality.HIGH -> R.string.settings_quality_high
                                                WallpaperQuality.ORIGINAL -> R.string.settings_quality_original
                                            }
                                            SegmentedButton(
                                                selected = settings.wallpaperQuality == quality,
                                                onClick = { onQualityChange(quality) },
                                                shape = SegmentedButtonDefaults.itemShape(
                                                    index = idx,
                                                    count = WallpaperQuality.entries.size
                                                ),
                                                modifier = Modifier.testTag("quality_${quality.name.lowercase()}")
                                            ) {
                                                Text(
                                                    text = stringResource(labelRes),
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = onResetWallpaperAdjustments,
                                        modifier = Modifier.testTag("reset_wallpaper_adjustments_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(stringResource(R.string.settings_wallpaper_reset))
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Language Section
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Language,
                        title = stringResource(R.string.settings_section_language),
                        alpha = cardAlpha
                    ) {
                        SingleChoiceSegmentedButtonRow(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val langs = listOf(
                                AppLanguage.SYSTEM to R.string.settings_lang_system,
                                AppLanguage.TURKISH to R.string.settings_lang_tr,
                                AppLanguage.ENGLISH to R.string.settings_lang_en
                            )
                            langs.forEachIndexed { idx, (lang, labelRes) ->
                                SegmentedButton(
                                    selected = settings.language == lang,
                                    onClick = { onSelectLanguage(lang) },
                                    shape = SegmentedButtonDefaults.itemShape(
                                        index = idx,
                                        count = langs.size
                                    ),
                                    modifier = Modifier.testTag("lang_option_${lang.tag}")
                                ) {
                                    Text(stringResource(labelRes))
                                }
                            }
                        }
                    }
                }

                // 4. About / Developer Credit Section
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Code,
                        title = stringResource(R.string.settings_section_about),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "v1.0",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(R.string.settings_developer_label),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = stringResource(R.string.developer_name),
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Security,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = stringResource(R.string.settings_privacy_note),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    alpha: Float,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface.copy(alpha = alpha),
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium
                )
            }
            content()
        }
    }
}

@Composable
private fun ThemeOptionTile(
    title: String,
    subtitle: String,
    bgPreview: Color,
    accent1: Color,
    accent2: Color,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(bgPreview)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                    )
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(accent1)
                    )
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(accent2)
                    )
                }

                if (selected) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WallpaperSliderRow(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag(testTag)
        )
    }
}
