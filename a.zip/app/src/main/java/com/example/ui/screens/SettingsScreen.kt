package com.example.ui.screens

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddAlarm
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppSettings
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.CardDensity
import com.example.data.preferences.FabStyleMode
import com.example.data.preferences.HomeLayoutMode
import com.example.data.preferences.ReminderTime
import com.example.data.preferences.WallpaperQuality
import com.example.data.preferences.WidgetStyleMode
import com.example.notifications.NotificationHelper
import com.example.ui.components.WallpaperBackground
import com.example.ui.theme.AmoledBg
import com.example.ui.theme.AmoledPrimary
import com.example.ui.theme.AmoledSecondary
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkSecondary
import com.example.ui.theme.LightBg
import com.example.ui.theme.LightPrimary
import com.example.ui.theme.LightSecondary
import com.example.ui.theme.LocalHasWallpaper
import com.example.ui.theme.NeonBg
import com.example.ui.theme.NeonPrimary
import com.example.ui.theme.NeonSecondary
import com.example.ui.viewmodel.SettingsViewModel
import com.example.widgets.InteractiveTasksWidgetProvider
import com.example.widgets.ProgressSummaryWidgetProvider
import com.example.widgets.WidgetBitmapRenderer
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    settingsViewModel: SettingsViewModel,
    onSelectLanguage: (AppLanguage) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val hasWallpaper = LocalHasWallpaper.current
    val cardAlpha = if (hasWallpaper) 0.85f else 1f

    var showTimePickerDialog by remember { mutableStateOf(false) }
    var pendingNotificationAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var stepInputText by remember(settings.defaultStepAmount) {
        mutableStateOf(settings.defaultStepAmount.toString())
    }

    val appWallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) settingsViewModel.saveWallpaper(uri)
    }

    val widgetWallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) settingsViewModel.saveWidgetWallpaper(uri)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            pendingNotificationAction?.invoke()
        } else {
            scope.launch {
                snackbarHostState.showSnackbar(context.getString(R.string.reminders_permission_needed))
            }
        }
        pendingNotificationAction = null
    }

    fun runWithNotificationPermission(action: () -> Unit) {
        if (NotificationHelper.hasNotificationPermission(context)) {
            action()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingNotificationAction = action
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            action()
        }
    }

    fun requestPinWidget(providerClass: Class<*>) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = AppWidgetManager.getInstance(context)
            if (manager.isRequestPinAppWidgetSupported) {
                val component = ComponentName(context, providerClass)
                val requested = manager.requestPinAppWidget(component, null, null)
                scope.launch {
                    snackbarHostState.showSnackbar(
                        context.getString(
                            if (requested) R.string.snackbar_widget_pin_requested
                            else R.string.snackbar_widget_pin_manual
                        )
                    )
                }
                return
            }
        }
        scope.launch {
            snackbarHostState.showSnackbar(context.getString(R.string.snackbar_widget_pin_manual))
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                title = {
                    Text(
                        text = stringResource(R.string.settings_title),
                        style = MaterialTheme.typography.headlineSmall
                    )
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 780.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Theme Selection
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Palette,
                        title = stringResource(R.string.settings_section_theme),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_light),
                                    subtitle = stringResource(R.string.settings_theme_light_desc),
                                    bgPreview = LightBg,
                                    accent1 = LightPrimary,
                                    accent2 = LightSecondary,
                                    selected = settings.themeMode == AppThemeMode.LIGHT,
                                    onClick = { settingsViewModel.setThemeMode(AppThemeMode.LIGHT) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_light_option")
                                )
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_dark),
                                    subtitle = stringResource(R.string.settings_theme_dark_desc),
                                    bgPreview = DarkBg,
                                    accent1 = DarkPrimary,
                                    accent2 = DarkSecondary,
                                    selected = settings.themeMode == AppThemeMode.DARK,
                                    onClick = { settingsViewModel.setThemeMode(AppThemeMode.DARK) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_dark_option")
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_amoled),
                                    subtitle = stringResource(R.string.settings_theme_amoled_desc),
                                    bgPreview = AmoledBg,
                                    accent1 = AmoledPrimary,
                                    accent2 = AmoledSecondary,
                                    selected = settings.themeMode == AppThemeMode.AMOLED,
                                    onClick = { settingsViewModel.setThemeMode(AppThemeMode.AMOLED) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_amoled_option")
                                )
                                ThemeOptionTile(
                                    title = stringResource(R.string.settings_theme_neon),
                                    subtitle = stringResource(R.string.settings_theme_neon_desc),
                                    bgPreview = NeonBg,
                                    accent1 = NeonPrimary,
                                    accent2 = NeonSecondary,
                                    selected = settings.themeMode == AppThemeMode.NEON,
                                    onClick = { settingsViewModel.setThemeMode(AppThemeMode.NEON) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("theme_neon_option")
                                )
                            }
                        }
                    }
                }

                // 2. Home Screen & Step Customization
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Tune,
                        title = stringResource(R.string.settings_section_home_custom),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = stringResource(R.string.custom_step_default_title),
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = stringResource(R.string.custom_step_default_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(1, 5, 10, 15, 20, 25).forEach { preset ->
                                    FilterChip(
                                        selected = settings.defaultStepAmount == preset,
                                        onClick = {
                                            stepInputText = preset.toString()
                                            settingsViewModel.setDefaultStepAmount(preset)
                                        },
                                        label = { Text("+$preset") },
                                        modifier = Modifier.testTag("settings_step_preset_$preset")
                                    )
                                }
                            }
                            OutlinedTextField(
                                value = stepInputText,
                                onValueChange = { raw ->
                                    val digits = raw.filter { it.isDigit() }.take(3)
                                    stepInputText = digits
                                    val parsed = digits.toIntOrNull()
                                    if (parsed != null && parsed in 1..100) {
                                        settingsViewModel.setDefaultStepAmount(parsed)
                                    }
                                },
                                label = { Text(stringResource(R.string.step_custom_label)) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("settings_step_custom_input")
                            )

                            Text(
                                text = stringResource(R.string.custom_layout_label),
                                style = MaterialTheme.typography.titleSmall
                            )
                            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                val modes = listOf(
                                    HomeLayoutMode.AUTO to R.string.custom_layout_auto,
                                    HomeLayoutMode.LIST to R.string.custom_layout_list,
                                    HomeLayoutMode.GRID to R.string.custom_layout_grid
                                )
                                modes.forEachIndexed { idx, (mode, labelRes) ->
                                    SegmentedButton(
                                        selected = settings.homeLayoutMode == mode,
                                        onClick = { settingsViewModel.setHomeLayoutMode(mode) },
                                        shape = SegmentedButtonDefaults.itemShape(idx, modes.size)
                                    ) {
                                        Text(stringResource(labelRes), maxLines = 1)
                                    }
                                }
                            }

                            Text(
                                text = stringResource(R.string.custom_density_label),
                                style = MaterialTheme.typography.titleSmall
                            )
                            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                val densities = listOf(
                                    CardDensity.COMFORTABLE to R.string.custom_density_comfortable,
                                    CardDensity.COMPACT to R.string.custom_density_compact
                                )
                                densities.forEachIndexed { idx, (density, labelRes) ->
                                    SegmentedButton(
                                        selected = settings.cardDensity == density,
                                        onClick = { settingsViewModel.setCardDensity(density) },
                                        shape = SegmentedButtonDefaults.itemShape(idx, densities.size)
                                    ) {
                                        Text(stringResource(labelRes), maxLines = 1)
                                    }
                                }
                            }

                            Text(
                                text = stringResource(R.string.custom_fab_style_label),
                                style = MaterialTheme.typography.titleSmall
                            )
                            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                val fabs = listOf(
                                    FabStyleMode.EXTENDED to R.string.custom_fab_extended,
                                    FabStyleMode.COMPACT_ICON to R.string.custom_fab_compact,
                                    FabStyleMode.CENTER_EXTENDED to R.string.custom_fab_center
                                )
                                fabs.forEachIndexed { idx, (mode, labelRes) ->
                                    SegmentedButton(
                                        selected = settings.fabStyleMode == mode,
                                        onClick = { settingsViewModel.setFabStyleMode(mode) },
                                        shape = SegmentedButtonDefaults.itemShape(idx, fabs.size)
                                    ) {
                                        Text(stringResource(labelRes), maxLines = 1)
                                    }
                                }
                            }

                            SliderRow(
                                label = stringResource(R.string.custom_corner_radius),
                                valueText = "${settings.cardCornerRadius} dp",
                                value = settings.cardCornerRadius.toFloat(),
                                valueRange = 8f..28f,
                                onValueChange = { settingsViewModel.setCardCornerRadius(it.roundToInt()) },
                                testTag = "settings_corner_radius_slider"
                            )

                            SliderRow(
                                label = stringResource(R.string.custom_card_opacity),
                                valueText = "%${(settings.cardOpacity * 100f).roundToInt()}",
                                value = settings.cardOpacity,
                                valueRange = 0.40f..1.0f,
                                onValueChange = settingsViewModel::setCardOpacity,
                                testTag = "settings_card_opacity_slider"
                            )

                            SettingsSwitchRow(
                                label = stringResource(R.string.custom_show_overview),
                                checked = settings.showOverviewCard,
                                onCheckedChange = settingsViewModel::setShowOverviewCard
                            )
                            SettingsSwitchRow(
                                label = stringResource(R.string.custom_show_status_filters),
                                checked = settings.showStatusFilters,
                                onCheckedChange = settingsViewModel::setShowStatusFilters
                            )
                            SettingsSwitchRow(
                                label = stringResource(R.string.custom_show_category_filters),
                                checked = settings.showCategoryFilters,
                                onCheckedChange = settingsViewModel::setShowCategoryFilters
                            )
                            SettingsSwitchRow(
                                label = stringResource(R.string.custom_show_notes),
                                checked = settings.showNotesOnCards,
                                onCheckedChange = settingsViewModel::setShowNotesOnCards
                            )
                            SettingsSwitchRow(
                                label = stringResource(R.string.custom_show_badges),
                                checked = settings.showBadgesOnCards,
                                onCheckedChange = settingsViewModel::setShowBadgesOnCards
                            )
                            SettingsSwitchRow(
                                label = stringResource(R.string.custom_show_deadlines),
                                checked = settings.showDeadlinesOnCards,
                                onCheckedChange = settingsViewModel::setShowDeadlinesOnCards
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = settingsViewModel::resetHomeCustomization,
                                    modifier = Modifier.testTag("settings_reset_home_button")
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(stringResource(R.string.custom_reset_home))
                                }
                            }
                        }
                    }
                }

                // 3. Reminder & Deadline Notifications
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.NotificationsActive,
                        title = stringResource(R.string.settings_section_reminders),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                                    Text(
                                        text = stringResource(R.string.reminders_enable_label),
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = stringResource(R.string.reminders_enable_desc),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = settings.remindersEnabled,
                                    onCheckedChange = { enable ->
                                        if (enable) {
                                            runWithNotificationPermission {
                                                settingsViewModel.setRemindersEnabled(true)
                                            }
                                        } else {
                                            settingsViewModel.setRemindersEnabled(false)
                                        }
                                    },
                                    modifier = Modifier.testTag("reminders_enable_switch")
                                )
                            }

                            Text(
                                text = stringResource(R.string.reminders_days_label),
                                style = MaterialTheme.typography.titleSmall
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val dayItems = listOf(
                                    1 to R.string.day_mon,
                                    2 to R.string.day_tue,
                                    3 to R.string.day_wed,
                                    4 to R.string.day_thu,
                                    5 to R.string.day_fri,
                                    6 to R.string.day_sat,
                                    7 to R.string.day_sun
                                )
                                dayItems.forEach { (isoDay, labelRes) ->
                                    FilterChip(
                                        selected = settings.reminderDays.contains(isoDay),
                                        onClick = { settingsViewModel.toggleReminderDay(isoDay) },
                                        label = { Text(stringResource(labelRes)) },
                                        modifier = Modifier.testTag("reminder_day_$isoDay")
                                    )
                                }
                            }

                            Text(
                                text = stringResource(R.string.reminders_times_label),
                                style = MaterialTheme.typography.titleSmall
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                settings.reminderTimes.forEach { time ->
                                    InputChip(
                                        selected = true,
                                        onClick = {
                                            if (settings.reminderTimes.size > 1) {
                                                settingsViewModel.removeReminderTime(time)
                                            }
                                        },
                                        label = { Text(time.formatted()) },
                                        trailingIcon = if (settings.reminderTimes.size > 1) {
                                            {
                                                Icon(
                                                    imageVector = Icons.Rounded.Close,
                                                    contentDescription = stringResource(R.string.action_delete),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        } else null,
                                        modifier = Modifier.testTag("reminder_time_${time.formatted()}")
                                    )
                                }

                                OutlinedButton(
                                    onClick = { showTimePickerDialog = true },
                                    modifier = Modifier.testTag("add_reminder_time_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AddAlarm,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(stringResource(R.string.reminders_add_time))
                                }
                            }

                            Text(
                                text = stringResource(R.string.reminders_deadline_info),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            OutlinedButton(
                                onClick = {
                                    runWithNotificationPermission {
                                        settingsViewModel.sendTestNotification()
                                        scope.launch {
                                            snackbarHostState.showSnackbar(
                                                context.getString(R.string.snackbar_test_notification_sent)
                                            )
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("send_test_notification_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.NotificationsActive,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.reminders_test_button))
                            }
                        }
                    }
                }

                // 4. Widget Customization Studio & Pinning
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Widgets,
                        title = stringResource(R.string.settings_section_widgets),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Live Widget Preview
                            val previewBitmap = remember(
                                settings.widgetWallpaperPath,
                                settings.widgetBlur,
                                settings.widgetSharpness,
                                settings.widgetDarkness,
                                settings.widgetStyleMode,
                                settings.themeMode
                            ) {
                                WidgetBitmapRenderer.renderWidgetBackground(settings, 640, 260).asImageBitmap()
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(125.dp)
                                    .clip(RoundedCornerShape(20.dp))
                            ) {
                                Image(
                                    bitmap = previewBitmap,
                                    contentDescription = stringResource(R.string.cd_wallpaper_preview),
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = stringResource(R.string.app_name),
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Text(
                                        text = stringResource(R.string.widget_interactive_desc, settings.defaultStepAmount),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                }
                            }

                            if (settings.widgetWallpaperPath == null) {
                                Text(
                                    text = stringResource(R.string.widget_bg_none),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        widgetWallpaperPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("pick_widget_wallpaper_button")
                                ) {
                                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        stringResource(
                                            if (settings.widgetWallpaperPath == null) R.string.widget_bg_pick
                                            else R.string.widget_bg_change
                                        )
                                    )
                                }

                                if (settings.widgetWallpaperPath != null) {
                                    OutlinedButton(
                                        onClick = settingsViewModel::clearWidgetWallpaper,
                                        modifier = Modifier.testTag("remove_widget_wallpaper_button")
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(stringResource(R.string.settings_wallpaper_remove))
                                    }
                                }
                            }

                            Text(
                                text = stringResource(R.string.widget_style_label),
                                style = MaterialTheme.typography.titleSmall
                            )
                            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                val styles = listOf(
                                    WidgetStyleMode.MATCH_APP to R.string.widget_style_theme,
                                    WidgetStyleMode.AMOLED to R.string.widget_style_amoled,
                                    WidgetStyleMode.NEON to R.string.widget_style_neon,
                                    WidgetStyleMode.GLASS to R.string.widget_style_glass
                                )
                                styles.forEachIndexed { idx, (style, labelRes) ->
                                    SegmentedButton(
                                        selected = settings.widgetStyleMode == style,
                                        onClick = { settingsViewModel.setWidgetStyleMode(style) },
                                        shape = SegmentedButtonDefaults.itemShape(idx, styles.size)
                                    ) {
                                        Text(stringResource(labelRes), maxLines = 1)
                                    }
                                }
                            }

                            if (settings.widgetWallpaperPath != null) {
                                SliderRow(
                                    label = stringResource(R.string.settings_wallpaper_blur),
                                    valueText = "${settings.widgetBlur.roundToInt()} dp",
                                    value = settings.widgetBlur,
                                    valueRange = 0f..25f,
                                    onValueChange = settingsViewModel::setWidgetBlur,
                                    testTag = "widget_blur_slider"
                                )
                                SliderRow(
                                    label = stringResource(R.string.settings_wallpaper_sharpness),
                                    valueText = "%${(settings.widgetSharpness * 100f).roundToInt()}",
                                    value = settings.widgetSharpness,
                                    valueRange = 0.2f..1.8f,
                                    onValueChange = settingsViewModel::setWidgetSharpness,
                                    testTag = "widget_sharpness_slider"
                                )
                                SliderRow(
                                    label = stringResource(R.string.settings_wallpaper_darkness),
                                    valueText = "%${(settings.widgetDarkness * 100f).roundToInt()}",
                                    value = settings.widgetDarkness,
                                    valueRange = 0f..0.92f,
                                    onValueChange = settingsViewModel::setWidgetDarkness,
                                    testTag = "widget_darkness_slider"
                                )
                            }

                            // Pin Widgets
                            WidgetPinCard(
                                title = stringResource(R.string.widget_summary_title),
                                description = stringResource(R.string.widget_summary_desc),
                                onPinClick = { requestPinWidget(ProgressSummaryWidgetProvider::class.java) },
                                testTag = "pin_summary_widget_button"
                            )
                            WidgetPinCard(
                                title = stringResource(R.string.widget_interactive_title),
                                description = stringResource(R.string.widget_interactive_desc, settings.defaultStepAmount),
                                onPinClick = { requestPinWidget(InteractiveTasksWidgetProvider::class.java) },
                                testTag = "pin_interactive_widget_button"
                            )
                        }
                    }
                }

                // 5. App Custom Wallpaper
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Image,
                        title = stringResource(R.string.settings_section_wallpaper),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (settings.wallpaperPath == null) {
                                Text(
                                    text = stringResource(R.string.settings_wallpaper_none),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                                ) {
                                    WallpaperBackground(
                                        wallpaperPath = settings.wallpaperPath,
                                        blurRadius = settings.wallpaperBlur,
                                        sharpness = settings.wallpaperSharpness,
                                        darkness = settings.wallpaperDarkness,
                                        quality = settings.wallpaperQuality
                                    )
                                    Surface(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(10.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)
                                    ) {
                                        Text(
                                            text = stringResource(R.string.cd_wallpaper_preview),
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        appWallpaperPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("pick_wallpaper_button")
                                ) {
                                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(
                                            if (settings.wallpaperPath == null) R.string.settings_wallpaper_pick
                                            else R.string.settings_wallpaper_change
                                        )
                                    )
                                }

                                if (settings.wallpaperPath != null) {
                                    OutlinedButton(
                                        onClick = settingsViewModel::clearWallpaper,
                                        modifier = Modifier.testTag("remove_wallpaper_button")
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(stringResource(R.string.settings_wallpaper_remove))
                                    }
                                }
                            }

                            if (settings.wallpaperPath != null) {
                                SliderRow(
                                    label = stringResource(R.string.settings_wallpaper_blur),
                                    valueText = "${settings.wallpaperBlur.roundToInt()} dp",
                                    value = settings.wallpaperBlur,
                                    valueRange = 0f..30f,
                                    onValueChange = settingsViewModel::setWallpaperBlur,
                                    testTag = "wallpaper_blur_slider"
                                )
                                SliderRow(
                                    label = stringResource(R.string.settings_wallpaper_sharpness),
                                    valueText = "%${(settings.wallpaperSharpness * 100f).roundToInt()}",
                                    value = settings.wallpaperSharpness,
                                    valueRange = 0.2f..1.8f,
                                    onValueChange = settingsViewModel::setWallpaperSharpness,
                                    testTag = "wallpaper_sharpness_slider"
                                )
                                SliderRow(
                                    label = stringResource(R.string.settings_wallpaper_darkness),
                                    valueText = "%${(settings.wallpaperDarkness * 100f).roundToInt()}",
                                    value = settings.wallpaperDarkness,
                                    valueRange = 0f..0.92f,
                                    onValueChange = settingsViewModel::setWallpaperDarkness,
                                    testTag = "wallpaper_darkness_slider"
                                )

                                Text(
                                    text = stringResource(R.string.settings_wallpaper_quality),
                                    style = MaterialTheme.typography.titleSmall
                                )
                                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                    WallpaperQuality.entries.forEachIndexed { idx, quality ->
                                        val labelRes = when (quality) {
                                            WallpaperQuality.LOW -> R.string.settings_quality_low
                                            WallpaperQuality.MEDIUM -> R.string.settings_quality_medium
                                            WallpaperQuality.HIGH -> R.string.settings_quality_high
                                            WallpaperQuality.ORIGINAL -> R.string.settings_quality_original
                                        }
                                        SegmentedButton(
                                            selected = settings.wallpaperQuality == quality,
                                            onClick = { settingsViewModel.setWallpaperQuality(quality) },
                                            shape = SegmentedButtonDefaults.itemShape(idx, WallpaperQuality.entries.size),
                                            modifier = Modifier.testTag("quality_${quality.name.lowercase()}")
                                        ) {
                                            Text(stringResource(labelRes), maxLines = 1)
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(
                                        onClick = settingsViewModel::resetWallpaperAdjustments,
                                        modifier = Modifier.testTag("reset_wallpaper_adjustments_button")
                                    ) {
                                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(stringResource(R.string.settings_wallpaper_reset))
                                    }
                                }
                            }
                        }
                    }
                }

                // 6. Language Selection
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Language,
                        title = stringResource(R.string.settings_section_language),
                        alpha = cardAlpha
                    ) {
                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                            val langs = listOf(
                                AppLanguage.SYSTEM to R.string.settings_lang_system,
                                AppLanguage.TURKISH to R.string.settings_lang_tr,
                                AppLanguage.ENGLISH to R.string.settings_lang_en
                            )
                            langs.forEachIndexed { idx, (lang, labelRes) ->
                                SegmentedButton(
                                    selected = settings.language == lang,
                                    onClick = { onSelectLanguage(lang) },
                                    shape = SegmentedButtonDefaults.itemShape(idx, langs.size),
                                    modifier = Modifier.testTag("lang_option_${lang.tag}")
                                ) {
                                    Text(stringResource(labelRes))
                                }
                            }
                        }
                    }
                }

                // 7. About / Developer Credit
                item {
                    SettingsSectionCard(
                        icon = Icons.Rounded.Code,
                        title = stringResource(R.string.settings_section_about),
                        alpha = cardAlpha
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "v1.0",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(R.string.settings_developer_label),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = stringResource(R.string.developer_name),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Security,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = stringResource(R.string.settings_privacy_note),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(24.dp)) }
            }
        }
    }

    if (showTimePickerDialog) {
        val pickerState = rememberTimePickerState(initialHour = 12, initialMinute = 0, is24Hour = true)
        AlertDialog(
            onDismissRequest = { showTimePickerDialog = false },
            title = { Text(stringResource(R.string.reminders_add_time)) },
            text = {
                TimePicker(state = pickerState)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        settingsViewModel.addReminderTime(
                            ReminderTime(pickerState.hour, pickerState.minute)
                        )
                        showTimePickerDialog = false
                    }
                ) {
                    Text(stringResource(R.string.action_add))
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePickerDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    alpha: Float,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface.copy(alpha = alpha),
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium
                )
            }
            content()
        }
    }
}

@Composable
private fun ThemeOptionTile(
    title: String,
    subtitle: String,
    bgPreview: Color,
    accent1: Color,
    accent2: Color,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(bgPreview)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                    )
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(accent1)
                    )
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(accent2)
                    )
                }

                if (selected) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WidgetPinCard(
    title: String,
    description: String,
    onPinClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(
                onClick = onPinClick,
                modifier = Modifier.testTag(testTag)
            ) {
                Text(stringResource(R.string.widget_pin_button))
            }
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag(testTag)
        )
    }
}
