package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ProgressMode
import com.example.data.local.TaskEntity
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun QuickProgressSheet(
    task: TaskEntity,
    onDismiss: () -> Unit,
    onApplyProgress: (
        mode: ProgressMode,
        newPercent: Int,
        newCompletedAmount: Int,
        newTargetAmount: Int
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var percent by remember(task) { mutableIntStateOf(task.progressPercent) }
    var percentText by remember(task) { mutableStateOf(task.progressPercent.toString()) }
    var completedText by remember(task) { mutableStateOf(task.completedAmount.toString()) }
    val targetAmount = task.targetAmount.coerceAtLeast(1)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .imePadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = stringResource(R.string.quick_progress_title),
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                text = task.title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = stringResource(R.string.quick_progress_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (task.progressMode == ProgressMode.PERCENTAGE) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Slider(
                        value = percent.toFloat(),
                        onValueChange = { v ->
                            val rounded = v.roundToInt().coerceIn(0, 100)
                            percent = rounded
                            percentText = rounded.toString()
                        },
                        valueRange = 0f..100f,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_percent_slider")
                    )

                    OutlinedTextField(
                        value = percentText,
                        onValueChange = { raw ->
                            val digits = raw.filter { it.isDigit() }.take(3)
                            percentText = digits
                            percent = digits.toIntOrNull()?.coerceIn(0, 100) ?: 0
                        },
                        label = { Text("%") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .width(92.dp)
                            .testTag("quick_percent_input")
                    )
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0, 25, 50, 75, 100).forEach { preset ->
                        FilterChip(
                            selected = percent == preset,
                            onClick = {
                                percent = preset
                                percentText = preset.toString()
                            },
                            label = { Text("%$preset") },
                            modifier = Modifier.testTag("quick_preset_$preset")
                        )
                    }
                }
            } else {
                val currentCompleted = (completedText.toIntOrNull() ?: 0).coerceIn(0, targetAmount)
                val computedPct = ((currentCompleted.toFloat() / targetAmount.toFloat()) * 100f)
                    .roundToInt()
                    .coerceIn(0, 100)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Slider(
                        value = currentCompleted.toFloat(),
                        onValueChange = { v ->
                            completedText = v.roundToInt().coerceIn(0, targetAmount).toString()
                        },
                        valueRange = 0f..targetAmount.toFloat(),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_amount_slider")
                    )

                    OutlinedTextField(
                        value = completedText,
                        onValueChange = { raw ->
                            completedText = raw.filter { it.isDigit() }.take(6)
                        },
                        label = { Text("/ $targetAmount") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .width(108.dp)
                            .testTag("quick_amount_input")
                    )
                }

                Text(
                    text = if (task.unitLabel.isNotBlank()) {
                        "$currentCompleted / $targetAmount ${task.unitLabel} (%$computedPct)"
                    } else {
                        "$currentCompleted / $targetAmount (%$computedPct)"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onApplyProgress(
                            task.progressMode,
                            100,
                            targetAmount,
                            targetAmount
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_complete_now_button")
                ) {
                    Icon(imageVector = Icons.Rounded.DoneAll, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_complete_now))
                }

                Button(
                    onClick = {
                        val finalPercent = (percentText.toIntOrNull() ?: percent).coerceIn(0, 100)
                        val finalAmount = (completedText.toIntOrNull() ?: 0).coerceIn(0, targetAmount)
                        onApplyProgress(
                            task.progressMode,
                            finalPercent,
                            finalAmount,
                            targetAmount
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_save_button")
                ) {
                    Text(stringResource(R.string.action_save))
                }
            }
        }
    }
}
