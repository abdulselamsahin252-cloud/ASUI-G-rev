package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ProgressMode
import com.example.data.local.TaskEntity
import com.example.data.preferences.AppSettings
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.CardDensity
import com.example.notifications.NotificationHelper
import com.example.ui.theme.LocalAppThemeMode
import com.example.ui.theme.LocalHasWallpaper

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskCard(
    task: TaskEntity,
    settings: AppSettings,
    onToggleComplete: () -> Unit,
    onStepProgress: (Int) -> Unit,
    onOpenQuickProgress: () -> Unit,
    onEditTask: () -> Unit,
    onDeleteTask: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val themeMode = LocalAppThemeMode.current
    val hasWallpaper = LocalHasWallpaper.current
    val percent = task.effectivePercent
    val isCompleted = task.isCompleted
    val completeColor = themeSuccessColor()
    val stepAmount = task.effectiveStep(settings.defaultStepAmount)
    val isCompact = settings.cardDensity == CardDensity.COMPACT
    val cardShape = RoundedCornerShape(settings.cardCornerRadius.dp)

    val deadlineMillis = task.deadlineAt
    val isExpired = deadlineMillis != null && deadlineMillis <= System.currentTimeMillis() && !isCompleted
    val remainingText = if (settings.showDeadlinesOnCards && task.hasDeadline) {
        NotificationHelper.formatRemainingShort(context, task)
    } else null

    val animatedProgress by animateFloatAsState(
        targetValue = percent / 100f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "task_progress_bar"
    )

    val barColor by animateColorAsState(
        targetValue = when {
            isCompleted -> completeColor
            isExpired -> MaterialTheme.colorScheme.error
            percent >= 50 -> MaterialTheme.colorScheme.primary
            percent > 0 -> MaterialTheme.colorScheme.secondary
            else -> MaterialTheme.colorScheme.outline
        },
        label = "task_bar_color"
    )

    val cardAlpha = if (hasWallpaper) {
        (settings.cardOpacity * if (isCompleted) 0.85f else 1f).coerceIn(0.35f, 1f)
    } else {
        settings.cardOpacity.coerceIn(0.75f, 1f)
    }

    val baseSurface = if (isCompleted) {
        MaterialTheme.colorScheme.surfaceContainerLow
    } else {
        MaterialTheme.colorScheme.surface
    }

    val cardContainerColor by animateColorAsState(
        targetValue = baseSurface.copy(alpha = cardAlpha),
        label = "task_card_bg"
    )

    val borderStroke = when {
        isExpired -> BorderStroke(1.2.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.7f))
        themeMode == AppThemeMode.NEON && !isCompleted -> BorderStroke(
            width = 1.2.dp,
            brush = Brush.horizontalGradient(
                listOf(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.65f)
                )
            )
        )
        else -> BorderStroke(
            width = 1.dp,
            color = if (isCompleted) {
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
        )
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_item_card_${task.id}")
            .clip(cardShape)
            .clickable(onClick = onEditTask),
        shape = cardShape,
        color = cardContainerColor,
        tonalElevation = if (isCompleted || themeMode == AppThemeMode.AMOLED) 0.dp else 2.dp,
        border = borderStroke
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = if (isCompact) 12.dp else 14.dp,
                    vertical = if (isCompact) 9.dp else 12.dp
                ),
            verticalArrangement = Arrangement.spacedBy(if (isCompact) 7.dp else 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_complete_button_${task.id}")
                        .clip(CircleShape)
                        .clickable(
                            onClickLabel = stringResource(R.string.cd_toggle_complete),
                            onClick = onToggleComplete
                        )
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (isCompact) 24.dp else 26.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCompleted) completeColor
                                else MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                            )
                            .border(
                                width = 2.dp,
                                color = if (isCompleted) completeColor else MaterialTheme.colorScheme.primary,
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = stringResource(R.string.cd_toggle_complete),
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (settings.showBadgesOnCards || remainingText != null) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (settings.showBadgesOnCards) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = task.category.containerColor()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = task.category.icon(),
                                            contentDescription = null,
                                            tint = task.category.contentColor(),
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Text(
                                            text = stringResource(task.category.labelRes()),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = task.category.contentColor()
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(task.priority.accentColor())
                                    )
                                    Text(
                                        text = stringResource(task.priority.labelRes()),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (remainingText != null) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = when {
                                        isExpired -> MaterialTheme.colorScheme.errorContainer
                                        isCompleted -> MaterialTheme.colorScheme.surfaceVariant
                                        else -> MaterialTheme.colorScheme.tertiaryContainer
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isExpired) Icons.Rounded.WarningAmber else Icons.Rounded.Schedule,
                                            contentDescription = null,
                                            tint = when {
                                                isExpired -> MaterialTheme.colorScheme.onErrorContainer
                                                isCompleted -> MaterialTheme.colorScheme.onSurfaceVariant
                                                else -> MaterialTheme.colorScheme.onTertiaryContainer
                                            },
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = remainingText,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = when {
                                                isExpired -> MaterialTheme.colorScheme.onErrorContainer
                                                isCompleted -> MaterialTheme.colorScheme.onSurfaceVariant
                                                else -> MaterialTheme.colorScheme.onTertiaryContainer
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            textDecoration = if (isCompleted) TextDecoration.LineThrough else TextDecoration.None
                        ),
                        color = if (isCompleted) {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        },
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (settings.showNotesOnCards && task.note.isNotBlank()) {
                        Text(
                            text = task.note,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = if (isCompact) 1 else 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(
                    onClick = onDeleteTask,
                    modifier = Modifier.testTag("delete_task_button_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = stringResource(R.string.cd_delete_task),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(
                            onClickLabel = stringResource(R.string.cd_edit_progress),
                            onClick = onOpenQuickProgress
                        )
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val progressDetailText = when (task.progressMode) {
                            ProgressMode.PERCENTAGE -> "%$percent"
                            ProgressMode.AMOUNT -> {
                                val unitPart = if (task.unitLabel.isNotBlank()) " ${task.unitLabel}" else ""
                                "${task.completedAmount}/${task.targetAmount}$unitPart (%$percent)"
                            }
                        }

                        Text(
                            text = progressDetailText,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            ),
                            color = barColor
                        )

                        if (!isCompact) {
                            Text(
                                text = stringResource(R.string.cd_edit_progress),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (isCompact) 6.dp else 8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(50))
                                .background(barColor)
                        )
                    }
                }

                // Customizable step increment/decrement buttons (-step / +step)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("decrease_progress_button_${task.id}")
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(
                                enabled = percent > 0,
                                onClickLabel = stringResource(R.string.cd_decrease_progress),
                                onClick = { onStepProgress(-1) }
                            ),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(
                            alpha = if (percent > 0) 1f else 0.40f
                        )
                    ) {
                        Box(
                            modifier = Modifier
                                .defaultMinSize(minWidth = 38.dp, minHeight = 32.dp)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "-$stepAmount",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("increase_progress_button_${task.id}")
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(
                                enabled = percent < 100,
                                onClickLabel = stringResource(R.string.cd_increase_progress),
                                onClick = { onStepProgress(1) }
                            ),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(
                            alpha = if (percent < 100) 1f else 0.40f
                        )
                    ) {
                        Box(
                            modifier = Modifier
                                .defaultMinSize(minWidth = 40.dp, minHeight = 32.dp)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "+$stepAmount",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
        }
    }
}
