package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.preferences.AppSettings
import com.example.data.preferences.FabStyleMode
import com.example.data.preferences.HomeLayoutMode
import com.example.ui.components.EmptyTasksState
import com.example.ui.components.HomeCustomizeSheet
import com.example.ui.components.ProgressOverviewCard
import com.example.ui.components.QuickProgressSheet
import com.example.ui.components.TaskCard
import com.example.ui.components.TaskEditorSheet
import com.example.ui.components.icon
import com.example.ui.components.labelRes
import com.example.ui.theme.LocalHasWallpaper
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.SortOrder
import com.example.ui.viewmodel.StatusFilter
import com.example.ui.viewmodel.TaskViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TaskViewModel,
    settingsViewModel: SettingsViewModel,
    settings: AppSettings,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val hasWallpaper = LocalHasWallpaper.current

    var showSearchBar by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showClearCompletedDialog by remember { mutableStateOf(false) }
    var showCustomizeSheet by remember { mutableStateOf(false) }

    var showEditorSheet by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<TaskEntity?>(null) }
    var quickProgressTask by remember { mutableStateOf<TaskEntity?>(null) }

    val hasActiveFilter = uiState.searchQuery.isNotBlank() ||
        uiState.statusFilter != StatusFilter.ALL ||
        uiState.selectedCategory != null

    val chipColors = FilterChipDefaults.filterChipColors(
        containerColor = MaterialTheme.colorScheme.surface.copy(
            alpha = if (hasWallpaper) 0.78f else 0.9f
        ),
        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
        selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
    )

    val fabPosition = when (settings.fabStyleMode) {
        FabStyleMode.CENTER_EXTENDED -> FabPosition.Center
        else -> FabPosition.End
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButtonPosition = fabPosition,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineSmall
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(
                                alpha = if (hasWallpaper) 0.85f else 1f
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CloudOff,
                                    contentDescription = stringResource(R.string.cd_offline_badge),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = stringResource(R.string.app_subtitle_offline),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            if (showSearchBar && uiState.searchQuery.isNotEmpty()) {
                                viewModel.updateSearchQuery("")
                            }
                            showSearchBar = !showSearchBar
                        },
                        modifier = Modifier.testTag("toggle_search_button")
                    ) {
                        Icon(
                            imageVector = if (showSearchBar) Icons.Rounded.Close else Icons.Rounded.Search,
                            contentDescription = stringResource(R.string.cd_search)
                        )
                    }

                    IconButton(
                        onClick = { showCustomizeSheet = true },
                        modifier = Modifier.testTag("customize_home_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Tune,
                            contentDescription = stringResource(R.string.cd_customize_home)
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { showSortMenu = true },
                            modifier = Modifier.testTag("sort_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Sort,
                                contentDescription = stringResource(R.string.cd_sort)
                            )
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            SortMenuOption(
                                label = stringResource(R.string.sort_newest),
                                selected = uiState.sortOrder == SortOrder.NEWEST,
                                onClick = {
                                    viewModel.setSortOrder(SortOrder.NEWEST)
                                    showSortMenu = false
                                }
                            )
                            SortMenuOption(
                                label = stringResource(R.string.sort_progress_desc),
                                selected = uiState.sortOrder == SortOrder.PROGRESS_DESC,
                                onClick = {
                                    viewModel.setSortOrder(SortOrder.PROGRESS_DESC)
                                    showSortMenu = false
                                }
                            )
                            SortMenuOption(
                                label = stringResource(R.string.sort_progress_asc),
                                selected = uiState.sortOrder == SortOrder.PROGRESS_ASC,
                                onClick = {
                                    viewModel.setSortOrder(SortOrder.PROGRESS_ASC)
                                    showSortMenu = false
                                }
                            )
                            SortMenuOption(
                                label = stringResource(R.string.sort_priority),
                                selected = uiState.sortOrder == SortOrder.PRIORITY,
                                onClick = {
                                    viewModel.setSortOrder(SortOrder.PRIORITY)
                                    showSortMenu = false
                                }
                            )
                            SortMenuOption(
                                label = stringResource(R.string.sort_deadline),
                                selected = uiState.sortOrder == SortOrder.DEADLINE,
                                onClick = {
                                    viewModel.setSortOrder(SortOrder.DEADLINE)
                                    showSortMenu = false
                                }
                            )
                        }
                    }

                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = stringResource(R.string.cd_settings)
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { showMoreMenu = true },
                            modifier = Modifier.testTag("more_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.MoreVert,
                                contentDescription = stringResource(R.string.cd_more_options)
                            )
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.action_clear_completed)) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteSweep,
                                        contentDescription = null
                                    )
                                },
                                enabled = uiState.completedCount > 0,
                                onClick = {
                                    showMoreMenu = false
                                    showClearCompletedDialog = true
                                }
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (settings.fabStyleMode == FabStyleMode.COMPACT_ICON) {
                FloatingActionButton(
                    onClick = {
                        editingTask = null
                        showEditorSheet = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("add_task_fab")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = stringResource(R.string.fab_add_task)
                    )
                }
            } else {
                ExtendedFloatingActionButton(
                    onClick = {
                        editingTask = null
                        showEditorSheet = true
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null
                        )
                    },
                    text = { Text(stringResource(R.string.fab_add_task)) },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("add_task_fab")
                )
            }
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            val columnCount = when (settings.homeLayoutMode) {
                HomeLayoutMode.AUTO -> if (maxWidth >= 700.dp) 2 else 1
                HomeLayoutMode.LIST -> 1
                HomeLayoutMode.GRID -> 2
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(columnCount),
                modifier = Modifier
                    .widthIn(max = 880.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 8.dp,
                    bottom = 96.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (settings.showOverviewCard) {
                    item(span = { GridItemSpan(columnCount) }) {
                        ProgressOverviewCard(
                            totalCount = uiState.totalCount,
                            completedCount = uiState.completedCount,
                            activeCount = uiState.activeCount,
                            averageProgress = uiState.averageProgress
                        )
                    }
                }

                item(span = { GridItemSpan(columnCount) }) {
                    AnimatedVisibility(
                        visible = showSearchBar,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        OutlinedTextField(
                            value = uiState.searchQuery,
                            onValueChange = viewModel::updateSearchQuery,
                            placeholder = { Text(stringResource(R.string.search_placeholder)) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = null
                                )
                            },
                            trailingIcon = {
                                if (uiState.searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { viewModel.updateSearchQuery("") },
                                        modifier = Modifier.testTag("clear_search_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = stringResource(R.string.cd_clear_search)
                                        )
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(
                                    alpha = if (hasWallpaper) 0.82f else 1f
                                ),
                                focusedContainerColor = MaterialTheme.colorScheme.surface.copy(
                                    alpha = if (hasWallpaper) 0.90f else 1f
                                )
                            ),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                                .testTag("search_input")
                        )
                    }
                }

                if (settings.showStatusFilters || settings.showCategoryFilters) {
                    item(span = { GridItemSpan(columnCount) }) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (settings.showStatusFilters) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilterChip(
                                        selected = uiState.statusFilter == StatusFilter.ALL,
                                        onClick = { viewModel.setStatusFilter(StatusFilter.ALL) },
                                        label = { Text(stringResource(R.string.filter_all)) },
                                        colors = chipColors,
                                        modifier = Modifier.testTag("filter_all_chip")
                                    )
                                    FilterChip(
                                        selected = uiState.statusFilter == StatusFilter.ACTIVE,
                                        onClick = { viewModel.setStatusFilter(StatusFilter.ACTIVE) },
                                        label = { Text(stringResource(R.string.filter_active)) },
                                        colors = chipColors,
                                        modifier = Modifier.testTag("filter_active_chip")
                                    )
                                    FilterChip(
                                        selected = uiState.statusFilter == StatusFilter.COMPLETED,
                                        onClick = { viewModel.setStatusFilter(StatusFilter.COMPLETED) },
                                        label = { Text(stringResource(R.string.filter_completed)) },
                                        colors = chipColors,
                                        modifier = Modifier.testTag("filter_completed_chip")
                                    )
                                }
                            }

                            if (settings.showCategoryFilters) {
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    item {
                                        FilterChip(
                                            selected = uiState.selectedCategory == null,
                                            onClick = { viewModel.setCategoryFilter(null) },
                                            label = { Text(stringResource(R.string.category_all)) },
                                            colors = chipColors,
                                            modifier = Modifier.testTag("filter_cat_all")
                                        )
                                    }
                                    items(TaskCategory.entries) { category ->
                                        FilterChip(
                                            selected = uiState.selectedCategory == category,
                                            onClick = { viewModel.setCategoryFilter(category) },
                                            label = { Text(stringResource(category.labelRes())) },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = category.icon(),
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            },
                                            colors = chipColors,
                                            modifier = Modifier.testTag("filter_cat_${category.name.lowercase()}")
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (uiState.hasLoaded && uiState.visibleTasks.isEmpty()) {
                    item(span = { GridItemSpan(columnCount) }) {
                        EmptyTasksState(
                            isFiltered = hasActiveFilter,
                            onAddTask = {
                                editingTask = null
                                showEditorSheet = true
                            },
                            onResetFilters = viewModel::resetFilters
                        )
                    }
                } else {
                    items(
                        items = uiState.visibleTasks,
                        key = { it.id }
                    ) { task ->
                        TaskCard(
                            task = task,
                            settings = settings,
                            onToggleComplete = { viewModel.toggleTaskCompleted(task) },
                            onStepProgress = { dir ->
                                viewModel.stepProgress(task, dir, settings.defaultStepAmount)
                            },
                            onOpenQuickProgress = { quickProgressTask = task },
                            onEditTask = {
                                editingTask = task
                                showEditorSheet = true
                            },
                            onDeleteTask = {
                                viewModel.deleteTask(task)
                                scope.launch {
                                    snackbarHostState.currentSnackbarData?.dismiss()
                                    val result = snackbarHostState.showSnackbar(
                                        message = context.getString(
                                            R.string.snackbar_task_deleted,
                                            task.title
                                        ),
                                        actionLabel = context.getString(R.string.action_undo),
                                        duration = SnackbarDuration.Short
                                    )
                                    if (result == SnackbarResult.ActionPerformed) {
                                        viewModel.undoLastDelete()
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCustomizeSheet) {
        HomeCustomizeSheet(
            settings = settings,
            onStepAmountChange = settingsViewModel::setDefaultStepAmount,
            onLayoutModeChange = settingsViewModel::setHomeLayoutMode,
            onDensityChange = settingsViewModel::setCardDensity,
            onFabStyleChange = settingsViewModel::setFabStyleMode,
            onCornerRadiusChange = settingsViewModel::setCardCornerRadius,
            onCardOpacityChange = settingsViewModel::setCardOpacity,
            onShowOverviewChange = settingsViewModel::setShowOverviewCard,
            onShowStatusFiltersChange = settingsViewModel::setShowStatusFilters,
            onShowCategoryFiltersChange = settingsViewModel::setShowCategoryFilters,
            onShowNotesChange = settingsViewModel::setShowNotesOnCards,
            onShowBadgesChange = settingsViewModel::setShowBadgesOnCards,
            onShowDeadlinesChange = settingsViewModel::setShowDeadlinesOnCards,
            onResetHome = settingsViewModel::resetHomeCustomization,
            onDismiss = { showCustomizeSheet = false }
        )
    }

    if (showEditorSheet) {
        TaskEditorSheet(
            existingTask = editingTask,
            defaultStepAmount = settings.defaultStepAmount,
            onDismiss = {
                showEditorSheet = false
                editingTask = null
            },
            onSave = { title, note, category, priority, mode, percent, completed, target, unit, customStep, days, hours, reminder ->
                viewModel.saveTask(
                    existingTask = editingTask,
                    title = title,
                    note = note,
                    category = category,
                    priority = priority,
                    progressMode = mode,
                    progressPercent = percent,
                    completedAmount = completed,
                    targetAmount = target,
                    unitLabel = unit,
                    customStepAmount = customStep,
                    durationDays = days,
                    durationHours = hours,
                    reminderEnabled = reminder
                )
                showEditorSheet = false
                editingTask = null
            }
        )
    }

    quickProgressTask?.let { targetTask ->
        QuickProgressSheet(
            task = targetTask,
            onDismiss = { quickProgressTask = null },
            onApplyProgress = { mode, newPercent, newCompleted, newTarget ->
                viewModel.updateTaskProgress(
                    task = targetTask,
                    mode = mode,
                    newPercent = newPercent,
                    newCompletedAmount = newCompleted,
                    newTargetAmount = newTarget
                )
                quickProgressTask = null
            }
        )
    }

    if (showClearCompletedDialog) {
        AlertDialog(
            onDismissRequest = { showClearCompletedDialog = false },
            title = { Text(stringResource(R.string.dialog_clear_completed_title)) },
            text = {
                Text(
                    stringResource(
                        R.string.dialog_clear_completed_message,
                        uiState.completedCount
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearCompleted()
                        showClearCompletedDialog = false
                        scope.launch {
                            snackbarHostState.showSnackbar(
                                message = context.getString(R.string.snackbar_completed_cleared),
                                duration = SnackbarDuration.Short
                            )
                        }
                    },
                    modifier = Modifier.testTag("confirm_clear_completed_button")
                ) {
                    Text(stringResource(R.string.action_delete))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showClearCompletedDialog = false },
                    modifier = Modifier.testTag("cancel_clear_completed_button")
                ) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun SortMenuOption(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = { Text(label) },
        trailingIcon = if (selected) {
            {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        } else null,
        onClick = onClick
    )
}
