package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ProgressMode
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TaskEditorSheet(
    existingTask: TaskEntity?,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        note: String,
        category: TaskCategory,
        priority: TaskPriority,
        progressMode: ProgressMode,
        progressPercent: Int,
        completedAmount: Int,
        targetAmount: Int,
        unitLabel: String
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var title by remember(existingTask) { mutableStateOf(existingTask?.title ?: "") }
    var note by remember(existingTask) { mutableStateOf(existingTask?.note ?: "") }
    var category by remember(existingTask) { mutableStateOf(existingTask?.category ?: TaskCategory.GENEL) }
    var priority by remember(existingTask) { mutableStateOf(existingTask?.priority ?: TaskPriority.ORTA) }
    var progressMode by remember(existingTask) {
        mutableStateOf(existingTask?.progressMode ?: ProgressMode.PERCENTAGE)
    }

    var percent by remember(existingTask) {
        mutableIntStateOf(existingTask?.progressPercent ?: 0)
    }
    var percentText by remember(existingTask) {
        mutableStateOf((existingTask?.progressPercent ?: 0).toString())
    }

    var completedAmountText by remember(existingTask) {
        mutableStateOf((existingTask?.completedAmount ?: 0).toString())
    }
    var targetAmountText by remember(existingTask) {
        mutableStateOf((existingTask?.targetAmount ?: 10).toString())
    }
    var unitLabel by remember(existingTask) {
        mutableStateOf(existingTask?.unitLabel ?: "")
    }
    var showTitleError by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .imePadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = stringResource(
                    if (existingTask == null) R.string.sheet_new_task else R.string.sheet_edit_task
                ),
                style = MaterialTheme.typography.headlineSmall
            )

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    if (it.isNotBlank()) showTitleError = false
                },
                label = { Text(stringResource(R.string.field_title_label)) },
                placeholder = { Text(stringResource(R.string.field_title_placeholder)) },
                isError = showTitleError,
                supportingText = if (showTitleError) {
                    { Text(stringResource(R.string.field_title_error)) }
                } else null,
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_title_input")
            )

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text(stringResource(R.string.field_note_label)) },
                placeholder = { Text(stringResource(R.string.field_note_placeholder)) },
                minLines = 2,
                maxLines = 4,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_note_input")
            )

            // Category Selection
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.section_category),
                    style = MaterialTheme.typography.titleSmall
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TaskCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(stringResource(cat.labelRes())) },
                            leadingIcon = {
                                Icon(
                                    imageVector = cat.icon(),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            modifier = Modifier.testTag("category_chip_${cat.name.lowercase()}")
                        )
                    }
                }
            }

            // Priority Selection
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.section_priority),
                    style = MaterialTheme.typography.titleSmall
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    TaskPriority.entries.forEachIndexed { index, item ->
                        SegmentedButton(
                            selected = priority == item,
                            onClick = { priority = item },
                            shape = SegmentedButtonDefaults.itemShape(
                                index = index,
                                count = TaskPriority.entries.size
                            ),
                            modifier = Modifier.testTag("priority_segment_${item.name.lowercase()}")
                        ) {
                            Text(stringResource(item.labelRes()))
                        }
                    }
                }
            }

            // Completion / Progress Input
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = stringResource(R.string.section_completion),
                    style = MaterialTheme.typography.titleSmall
                )

                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = progressMode == ProgressMode.PERCENTAGE,
                        onClick = { progressMode = ProgressMode.PERCENTAGE },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("mode_percentage_button")
                    ) {
                        Text(stringResource(R.string.mode_percentage))
                    }
                    SegmentedButton(
                        selected = progressMode == ProgressMode.AMOUNT,
                        onClick = { progressMode = ProgressMode.AMOUNT },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("mode_amount_button")
                    ) {
                        Text(stringResource(R.string.mode_amount))
                    }
                }

                if (progressMode == ProgressMode.PERCENTAGE) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Slider(
                            value = percent.toFloat(),
                            onValueChange = { value ->
                                val rounded = value.roundToInt().coerceIn(0, 100)
                                percent = rounded
                                percentText = rounded.toString()
                            },
                            valueRange = 0f..100f,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("editor_percent_slider")
                        )

                        OutlinedTextField(
                            value = percentText,
                            onValueChange = { raw ->
                                val digits = raw.filter { it.isDigit() }.take(3)
                                percentText = digits
                                val parsed = digits.toIntOrNull()
                                if (parsed != null) {
                                    percent = parsed.coerceIn(0, 100)
                                } else if (digits.isEmpty()) {
                                    percent = 0
                                }
                            },
                            label = { Text("%") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .width(90.dp)
                                .testTag("editor_percent_input")
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0, 25, 50, 75, 100).forEach { preset ->
                            FilterChip(
                                selected = percent == preset,
                                onClick = {
                                    percent = preset
                                    percentText = preset.toString()
                                },
                                label = { Text("%$preset") },
                                modifier = Modifier.testTag("preset_chip_$preset")
                            )
                        }
                    }
                } else {
                    val completedVal = completedAmountText.toIntOrNull()?.coerceAtLeast(0) ?: 0
                    val targetVal = (targetAmountText.toIntOrNull() ?: 10).coerceAtLeast(1)
                    val computedPercent = ((completedVal.toFloat() / targetVal.toFloat()) * 100f)
                        .roundToInt()
                        .coerceIn(0, 100)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = completedAmountText,
                            onValueChange = { raw ->
                                completedAmountText = raw.filter { it.isDigit() }.take(6)
                            },
                            label = { Text(stringResource(R.string.field_completed_amount_label)) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("editor_completed_amount_input")
                        )
                        OutlinedTextField(
                            value = targetAmountText,
                            onValueChange = { raw ->
                                targetAmountText = raw.filter { it.isDigit() }.take(6)
                            },
                            label = { Text(stringResource(R.string.field_target_amount_label)) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("editor_target_amount_input")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = unitLabel,
                            onValueChange = { unitLabel = it },
                            label = { Text(stringResource(R.string.field_unit_label)) },
                            placeholder = { Text(stringResource(R.string.field_unit_placeholder)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("editor_unit_input")
                        )

                        Text(
                            text = "%$computedPercent",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("editor_cancel_button")
                ) {
                    Text(stringResource(R.string.action_cancel))
                }

                Button(
                    onClick = {
                        if (title.isBlank()) {
                            showTitleError = true
                            return@Button
                        }
                        val parsedPercent = (percentText.toIntOrNull() ?: percent).coerceIn(0, 100)
                        val parsedTarget = (targetAmountText.toIntOrNull() ?: 10).coerceAtLeast(1)
                        val parsedCompleted = (completedAmountText.toIntOrNull() ?: 0)
                            .coerceIn(0, parsedTarget)

                        onSave(
                            title,
                            note,
                            category,
                            priority,
                            progressMode,
                            parsedPercent,
                            parsedCompleted,
                            parsedTarget,
                            unitLabel
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("editor_save_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircleOutline,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.action_save))
                }
            }
        }
    }
}
