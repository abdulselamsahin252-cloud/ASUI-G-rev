package com.example.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.ProgressMode
import com.example.data.local.TaskEntity
import com.example.data.preferences.AppSettings
import com.example.data.preferences.SettingsRepository
import com.example.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class ProgressSummaryWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val tasks = AppDatabase.getInstance(appContext).taskDao().getAllTasksOnce()
                val settings = SettingsRepository(appContext).getSettingsOnce()
                updateWidgets(appContext, appWidgetManager, appWidgetIds, tasks, settings)
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        fun updateWidgets(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetIds: IntArray,
            tasks: List<TaskEntity>,
            settings: AppSettings
        ) {
            val ctx = NotificationHelper.localizedContext(context)
            val palette = WidgetBitmapRenderer.resolvePalette(settings)
            val bgBitmap = WidgetBitmapRenderer.renderWidgetBackground(settings, 760, 380)

            val total = tasks.size
            val completed = tasks.count { it.isCompleted }
            val activeTasks = tasks.filter { !it.isCompleted }
            val avg = if (tasks.isEmpty()) 0 else tasks.map { it.effectivePercent }.average().roundToInt()

            val ringBitmap = WidgetBitmapRenderer.renderProgressRing(
                percent = avg,
                primaryColor = palette.primary,
                secondaryColor = palette.secondary,
                trackColor = palette.trackColor,
                textColor = palette.textPrimary,
                sizePx = 190
            )

            val openIntent = PendingIntent.getActivity(
                ctx,
                901,
                Intent(ctx, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            appWidgetIds.forEach { widgetId ->
                val views = RemoteViews(ctx.packageName, R.layout.widget_progress_summary)
                views.setOnClickPendingIntent(R.id.widget_summary_root, openIntent)
                views.setImageViewBitmap(R.id.widget_summary_bg, bgBitmap)
                views.setImageViewBitmap(R.id.widget_summary_ring, ringBitmap)

                views.setTextViewText(R.id.widget_summary_app_name, ctx.getString(R.string.app_name))
                views.setTextColor(R.id.widget_summary_app_name, palette.primary)

                val countText = if (total == 0) {
                    ctx.getString(R.string.widget_no_tasks)
                } else {
                    ctx.getString(R.string.overview_completed_count, completed, total)
                }
                views.setTextViewText(R.id.widget_summary_count, countText)
                views.setTextColor(R.id.widget_summary_count, palette.textPrimary)

                val preview1 = activeTasks.getOrNull(0)
                val preview2 = activeTasks.getOrNull(1)

                if (preview1 != null) {
                    views.setViewVisibility(R.id.widget_summary_task1, View.VISIBLE)
                    views.setTextViewText(R.id.widget_summary_task1, formatTaskLine(preview1))
                    views.setTextColor(R.id.widget_summary_task1, palette.textSecondary)
                } else {
                    views.setViewVisibility(R.id.widget_summary_task1, View.VISIBLE)
                    views.setTextViewText(R.id.widget_summary_task1, ctx.getString(R.string.widget_add_hint))
                    views.setTextColor(R.id.widget_summary_task1, palette.textSecondary)
                }

                if (preview2 != null) {
                    views.setViewVisibility(R.id.widget_summary_task2, View.VISIBLE)
                    views.setTextViewText(R.id.widget_summary_task2, formatTaskLine(preview2))
                    views.setTextColor(R.id.widget_summary_task2, palette.textSecondary)
                } else {
                    views.setViewVisibility(R.id.widget_summary_task2, View.GONE)
                }

                appWidgetManager.updateAppWidget(widgetId, views)
            }
        }

        private fun formatTaskLine(task: TaskEntity): String {
            val pct = task.effectivePercent
            return if (task.progressMode == ProgressMode.AMOUNT) {
                val u = if (task.unitLabel.isNotBlank()) " ${task.unitLabel}" else ""
                "• ${task.title} (${task.completedAmount}/${task.targetAmount}$u • %$pct)"
            } else {
                "• ${task.title} (%$pct)"
            }
        }
    }
}
