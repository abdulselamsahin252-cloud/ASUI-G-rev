package com.example.widgets

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.AppDatabase
import com.example.data.local.ProgressMode
import com.example.data.preferences.SettingsRepository
import com.example.notifications.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WidgetActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_STEP_TASK = "com.example.WIDGET_STEP_TASK"
        const val ACTION_COMPLETE_TASK = "com.example.WIDGET_COMPLETE_TASK"
        const val ACTION_REFRESH = "com.example.WIDGET_REFRESH"
        const val EXTRA_TASK_ID = "extra_widget_task_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.getInstance(appContext).taskDao()
                val settings = SettingsRepository(appContext).getSettingsOnce()

                when (intent.action) {
                    ACTION_STEP_TASK -> {
                        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
                        val task = if (taskId > 0L) dao.getTaskById(taskId) else null
                        if (task != null) {
                            val step = task.effectiveStep(settings.defaultStepAmount)
                            val updated = when (task.progressMode) {
                                ProgressMode.PERCENTAGE -> {
                                    val next = (task.progressPercent + step).coerceIn(0, 100)
                                    task.copy(
                                        progressPercent = next,
                                        lastNonFullPercent = if (next < 100) next else task.lastNonFullPercent,
                                        updatedAt = System.currentTimeMillis()
                                    )
                                }
                                ProgressMode.AMOUNT -> {
                                    val safeTarget = task.targetAmount.coerceAtLeast(1)
                                    val next = (task.completedAmount + step).coerceIn(0, safeTarget)
                                    task.copy(
                                        completedAmount = next,
                                        lastNonFullAmount = if (next < safeTarget) next else task.lastNonFullAmount,
                                        updatedAt = System.currentTimeMillis()
                                    )
                                }
                            }
                            dao.upsertTask(updated)
                            ReminderScheduler.scheduleTaskDeadlines(appContext, dao.getAllTasksOnce())
                        }
                    }

                    ACTION_COMPLETE_TASK -> {
                        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
                        val task = if (taskId > 0L) dao.getTaskById(taskId) else null
                        if (task != null) {
                            val updated = when (task.progressMode) {
                                ProgressMode.PERCENTAGE -> task.copy(
                                    lastNonFullPercent = task.progressPercent.coerceIn(0, 99),
                                    progressPercent = 100,
                                    updatedAt = System.currentTimeMillis()
                                )
                                ProgressMode.AMOUNT -> {
                                    val safeTarget = task.targetAmount.coerceAtLeast(1)
                                    task.copy(
                                        lastNonFullAmount = task.completedAmount.coerceIn(0, safeTarget - 1),
                                        completedAmount = safeTarget,
                                        updatedAt = System.currentTimeMillis()
                                    )
                                }
                            }
                            dao.upsertTask(updated)
                            ReminderScheduler.scheduleTaskDeadlines(appContext, dao.getAllTasksOnce())
                        }
                    }
                }

                WidgetUpdater.updateAllSync(appContext)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
