package com.example.widgets

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.example.data.preferences.AppSettings
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.WidgetStyleMode
import kotlin.math.max
import kotlin.math.roundToInt

object WidgetBitmapRenderer {

    data class WidgetPalette(
        val bgStart: Int,
        val bgEnd: Int,
        val borderStart: Int,
        val borderEnd: Int,
        val primary: Int,
        val secondary: Int,
        val textPrimary: Int,
        val textSecondary: Int,
        val trackColor: Int,
        val buttonBg: Int
    )

    fun resolvePalette(settings: AppSettings): WidgetPalette {
        val effectiveStyle = when (settings.widgetStyleMode) {
            WidgetStyleMode.MATCH_APP -> when (settings.themeMode) {
                AppThemeMode.LIGHT -> WidgetStyleMode.GLASS
                AppThemeMode.DARK -> WidgetStyleMode.MATCH_APP
                AppThemeMode.AMOLED -> WidgetStyleMode.AMOLED
                AppThemeMode.NEON -> WidgetStyleMode.NEON
            }
            else -> settings.widgetStyleMode
        }

        val hasImage = settings.widgetWallpaperPath != null

        return when (effectiveStyle) {
            WidgetStyleMode.NEON -> WidgetPalette(
                bgStart = Color.parseColor("#110B26"),
                bgEnd = Color.parseColor("#080514"),
                borderStart = Color.parseColor("#00F5D4"),
                borderEnd = Color.parseColor("#FF2E93"),
                primary = Color.parseColor("#00F5D4"),
                secondary = Color.parseColor("#FF2E93"),
                textPrimary = Color.parseColor("#F8FAFC"),
                textSecondary = Color.parseColor("#C4B5FD"),
                trackColor = Color.parseColor("#33FFFFFF"),
                buttonBg = Color.parseColor("#2A00F5D4")
            )
            WidgetStyleMode.AMOLED -> WidgetPalette(
                bgStart = Color.parseColor("#050507"),
                bgEnd = Color.parseColor("#000000"),
                borderStart = Color.parseColor("#2DD4BF"),
                borderEnd = Color.parseColor("#1E293B"),
                primary = Color.parseColor("#2DD4BF"),
                secondary = Color.parseColor("#60A5FA"),
                textPrimary = Color.parseColor("#F8FAFC"),
                textSecondary = Color.parseColor("#94A3B8"),
                trackColor = Color.parseColor("#26FFFFFF"),
                buttonBg = Color.parseColor("#262DD4BF")
            )
            WidgetStyleMode.GLASS -> if (hasImage) {
                WidgetPalette(
                    bgStart = Color.parseColor("#141923"),
                    bgEnd = Color.parseColor("#0E121A"),
                    borderStart = Color.parseColor("#66FFFFFF"),
                    borderEnd = Color.parseColor("#33FFFFFF"),
                    primary = Color.parseColor("#38BDF8"),
                    secondary = Color.parseColor("#34D399"),
                    textPrimary = Color.parseColor("#FFFFFF"),
                    textSecondary = Color.parseColor("#DCE6F5"),
                    trackColor = Color.parseColor("#33FFFFFF"),
                    buttonBg = Color.parseColor("#3338BDF8")
                )
            } else {
                WidgetPalette(
                    bgStart = Color.parseColor("#F8FAFC"),
                    bgEnd = Color.parseColor("#E8EEF7"),
                    borderStart = Color.parseColor("#CBD5E1"),
                    borderEnd = Color.parseColor("#94A3B8"),
                    primary = Color.parseColor("#4338CA"),
                    secondary = Color.parseColor("#0D9488"),
                    textPrimary = Color.parseColor("#0F172A"),
                    textSecondary = Color.parseColor("#475569"),
                    trackColor = Color.parseColor("#220F172A"),
                    buttonBg = Color.parseColor("#1F4338CA")
                )
            }
            WidgetStyleMode.MATCH_APP -> WidgetPalette(
                bgStart = Color.parseColor("#161D29"),
                bgEnd = Color.parseColor("#0D1117"),
                borderStart = Color.parseColor("#38BDF8"),
                borderEnd = Color.parseColor("#334155"),
                primary = Color.parseColor("#38BDF8"),
                secondary = Color.parseColor("#34D399"),
                textPrimary = Color.parseColor("#F8FAFC"),
                textSecondary = Color.parseColor("#A5B4CC"),
                trackColor = Color.parseColor("#26FFFFFF"),
                buttonBg = Color.parseColor("#2638BDF8")
            )
        }
    }

    fun renderWidgetBackground(
        settings: AppSettings,
        widthPx: Int = 720,
        heightPx: Int = 420
    ): Bitmap {
        val palette = resolvePalette(settings)
        val out = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val rect = RectF(0f, 0f, widthPx.toFloat(), heightPx.toFloat())
        val radius = 42f

        val clipPath = Path().apply {
            addRoundRect(rect, radius, radius, Path.Direction.CW)
        }
        canvas.save()
        canvas.clipPath(clipPath)

        val rawPhoto = settings.widgetWallpaperPath?.let { path ->
            decodeSampledBitmap(path, widthPx, heightPx)
        }

        if (rawPhoto != null) {
            val blurred = if (settings.widgetBlur >= 1f) {
                val downscaled = Bitmap.createScaledBitmap(
                    rawPhoto,
                    (widthPx / 4).coerceAtLeast(48),
                    (heightPx / 4).coerceAtLeast(48),
                    true
                )
                rawPhoto.recycle()
                boxBlur(downscaled, (settings.widgetBlur / 2.2f).roundToInt().coerceIn(1, 10))
            } else {
                rawPhoto
            }

            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                colorFilter = buildSharpnessFilter(settings.widgetSharpness)
            }
            val srcRect = centerCropSrcRect(blurred.width, blurred.height, widthPx, heightPx)
            canvas.drawBitmap(blurred, srcRect, rect, paint)
            blurred.recycle()

            val darknessAlpha = (settings.widgetDarkness.coerceIn(0f, 0.92f) * 255).roundToInt()
            if (darknessAlpha > 0) {
                canvas.drawColor(Color.argb(darknessAlpha, 0, 0, 0))
            }
        } else {
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, widthPx.toFloat(), heightPx.toFloat(),
                    palette.bgStart, palette.bgEnd, Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(rect, bgPaint)
        }
        canvas.restore()

        // Border stroke
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            shader = LinearGradient(
                0f, 0f, widthPx.toFloat(), heightPx.toFloat(),
                palette.borderStart, palette.borderEnd, Shader.TileMode.CLAMP
            )
        }
        val insetRect = RectF(2f, 2f, widthPx - 2f, heightPx - 2f)
        canvas.drawRoundRect(insetRect, radius, radius, borderPaint)

        return out
    }

    fun renderProgressRing(
        percent: Int,
        primaryColor: Int,
        secondaryColor: Int,
        trackColor: Int,
        textColor: Int,
        sizePx: Int = 180
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val stroke = sizePx * 0.11f
        val pad = stroke / 2f + 4f
        val arcRect = RectF(pad, pad, sizePx - pad, sizePx - pad)

        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = stroke
            strokeCap = Paint.Cap.ROUND
            color = trackColor
        }
        canvas.drawArc(arcRect, -90f, 360f, false, trackPaint)

        val sweep = (percent.coerceIn(0, 100) / 100f) * 360f
        if (sweep > 0f) {
            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = stroke
                strokeCap = Paint.Cap.ROUND
                shader = LinearGradient(
                    0f, 0f, sizePx.toFloat(), sizePx.toFloat(),
                    primaryColor, secondaryColor, Shader.TileMode.CLAMP
                )
            }
            canvas.drawArc(arcRect, -90f, sweep, false, fillPaint)
        }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = sizePx * 0.25f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        val fm = textPaint.fontMetrics
        val baseline = (sizePx / 2f) - (fm.ascent + fm.descent) / 2f
        canvas.drawText("%${percent.coerceIn(0, 100)}", sizePx / 2f, baseline, textPaint)

        return bitmap
    }

    fun renderProgressBar(
        percent: Int,
        fillColor: Int,
        trackColor: Int,
        widthPx: Int = 440,
        heightPx: Int = 16
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val r = heightPx / 2f
        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = trackColor }
        canvas.drawRoundRect(RectF(0f, 0f, widthPx.toFloat(), heightPx.toFloat()), r, r, trackPaint)

        val fillWidth = (widthPx * (percent.coerceIn(0, 100) / 100f)).coerceAtLeast(
            if (percent > 0) heightPx.toFloat() else 0f
        )
        if (fillWidth > 0f) {
            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor }
            canvas.drawRoundRect(RectF(0f, 0f, fillWidth, heightPx.toFloat()), r, r, fillPaint)
        }
        return bitmap
    }

    private fun decodeSampledBitmap(path: String, reqW: Int, reqH: Int): Bitmap? {
        return runCatching {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            val maxDim = max(opts.outWidth, opts.outHeight)
            val targetMax = max(reqW, reqH)
            var sample = 1
            while ((maxDim / (sample * 2)) >= targetMax) {
                sample *= 2
            }
            BitmapFactory.decodeFile(
                path,
                BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
            )
        }.getOrNull()
    }

    private fun centerCropSrcRect(srcW: Int, srcH: Int, dstW: Int, dstH: Int): Rect {
        val srcRatio = srcW.toFloat() / srcH.toFloat()
        val dstRatio = dstW.toFloat() / dstH.toFloat()
        return if (srcRatio > dstRatio) {
            val cropW = (srcH * dstRatio).roundToInt()
            val left = (srcW - cropW) / 2
            Rect(left, 0, left + cropW, srcH)
        } else {
            val cropH = (srcW / dstRatio).roundToInt()
            val top = (srcH - cropH) / 2
            Rect(0, top, srcW, top + cropH)
        }
    }

    private fun buildSharpnessFilter(sharpness: Float): ColorMatrixColorFilter {
        val clamped = sharpness.coerceIn(0.2f, 1.8f)
        val contrast = 0.65f + (clamped * 0.35f)
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val sat = 0.55f + (clamped * 0.45f)

        val m = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val satM = ColorMatrix().apply { setSaturation(sat) }
        m.preConcat(satM)
        return ColorMatrixColorFilter(m)
    }

    private fun boxBlur(bitmap: Bitmap, radius: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)

        repeat(2) {
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    var r = 0
                    var g = 0
                    var b = 0
                    var c = 0
                    for (kx in (x - radius).coerceAtLeast(0)..(x + radius).coerceAtMost(w - 1)) {
                        val p = pixels[row + kx]
                        r += (p ushr 16) and 0xFF
                        g += (p ushr 8) and 0xFF
                        b += p and 0xFF
                        c++
                    }
                    out[row + x] = (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
                }
            }
            for (x in 0 until w) {
                for (y in 0 until h) {
                    var r = 0
                    var g = 0
                    var b = 0
                    var c = 0
                    for (ky in (y - radius).coerceAtLeast(0)..(y + radius).coerceAtMost(h - 1)) {
                        val p = out[ky * w + x]
                        r += (p ushr 16) and 0xFF
                        g += (p ushr 8) and 0xFF
                        b += p and 0xFF
                        c++
                    }
                    pixels[y * w + x] = (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
                }
            }
        }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(pixels, 0, w, 0, 0, w, h)
        bitmap.recycle()
        return res
    }
}
