package com.example.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.ProgressMode
import com.example.data.local.TaskEntity
import com.example.data.preferences.AppSettings
import com.example.data.preferences.SettingsRepository
import com.example.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InteractiveTasksWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val tasks = AppDatabase.getInstance(appContext).taskDao().getAllTasksOnce()
                val settings = SettingsRepository(appContext).getSettingsOnce()
                updateWidgets(appContext, appWidgetManager, appWidgetIds, tasks, settings)
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        fun updateWidgets(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetIds: IntArray,
            tasks: List<TaskEntity>,
            settings: AppSettings
        ) {
            val ctx = NotificationHelper.localizedContext(context)
            val palette = WidgetBitmapRenderer.resolvePalette(settings)
            val bgBitmap = WidgetBitmapRenderer.renderWidgetBackground(settings, 760, 560)
            val activeTasks = tasks.filter { !it.isCompleted }.take(3)

            val openIntent = PendingIntent.getActivity(
                ctx,
                902,
                Intent(ctx, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val refreshIntent = PendingIntent.getBroadcast(
                ctx,
                903,
                Intent(ctx, WidgetActionReceiver::class.java).apply {
                    action = WidgetActionReceiver.ACTION_REFRESH
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            appWidgetIds.forEach { widgetId ->
                val views = RemoteViews(ctx.packageName, R.layout.widget_interactive_tasks)
                views.setImageViewBitmap(R.id.widget_list_bg, bgBitmap)
                views.setOnClickPendingIntent(R.id.widget_list_header, openIntent)
                views.setOnClickPendingIntent(R.id.widget_list_refresh, refreshIntent)

                views.setTextViewText(R.id.widget_list_title, ctx.getString(R.string.app_name))
                views.setTextColor(R.id.widget_list_title, palette.primary)
                views.setTextViewText(
                    R.id.widget_list_badge,
                    ctx.getString(R.string.widget_active_label, tasks.count { !it.isCompleted })
                )
                views.setTextColor(R.id.widget_list_badge, palette.textSecondary)

                if (activeTasks.isEmpty()) {
                    views.setViewVisibility(R.id.widget_list_empty, View.VISIBLE)
                    views.setTextViewText(R.id.widget_list_empty, ctx.getString(R.string.widget_no_tasks))
                    views.setTextColor(R.id.widget_list_empty, palette.textSecondary)
                } else {
                    views.setViewVisibility(R.id.widget_list_empty, View.GONE)
                }

                val rowIds = listOf(
                    RowViewIds(
                        container = R.id.widget_row_1,
                        title = R.id.widget_row_1_title,
                        meta = R.id.widget_row_1_meta,
                        bar = R.id.widget_row_1_bar,
                        stepBtn = R.id.widget_row_1_step,
                        doneBtn = R.id.widget_row_1_done
                    ),
                    RowViewIds(
                        container = R.id.widget_row_2,
                        title = R.id.widget_row_2_title,
                        meta = R.id.widget_row_2_meta,
                        bar = R.id.widget_row_2_bar,
                        stepBtn = R.id.widget_row_2_step,
                        doneBtn = R.id.widget_row_2_done
                    ),
                    RowViewIds(
                        container = R.id.widget_row_3,
                        title = R.id.widget_row_3_title,
                        meta = R.id.widget_row_3_meta,
                        bar = R.id.widget_row_3_bar,
                        stepBtn = R.id.widget_row_3_step,
                        doneBtn = R.id.widget_row_3_done
                    )
                )

                rowIds.forEachIndexed { index, ids ->
                    val task = activeTasks.getOrNull(index)
                    if (task == null) {
                        views.setViewVisibility(ids.container, View.GONE)
                    } else {
                        views.setViewVisibility(ids.container, View.VISIBLE)
                        views.setTextViewText(ids.title, task.title)
                        views.setTextColor(ids.title, palette.textPrimary)

                        val pct = task.effectivePercent
                        val step = task.effectiveStep(settings.defaultStepAmount)
                        val remaining = NotificationHelper.formatRemainingShort(ctx, task)
                        val progressTxt = if (task.progressMode == ProgressMode.AMOUNT) {
                            val unit = if (task.unitLabel.isNotBlank()) " ${task.unitLabel}" else ""
                            "${task.completedAmount}/${task.targetAmount}$unit • %$pct"
                        } else {
                            "%$pct"
                        }
                        val metaTxt = if (remaining != null) "$progressTxt • $remaining" else progressTxt
                        views.setTextViewText(ids.meta, metaTxt)
                        views.setTextColor(ids.meta, palette.textSecondary)

                        val barBitmap = WidgetBitmapRenderer.renderProgressBar(
                            percent = pct,
                            fillColor = palette.primary,
                            trackColor = palette.trackColor
                        )
                        views.setImageViewBitmap(ids.bar, barBitmap)

                        views.setTextViewText(ids.stepBtn, "+$step")
                        views.setTextColor(ids.stepBtn, palette.primary)
                        views.setTextColor(ids.doneBtn, palette.secondary)

                        val stepIntent = PendingIntent.getBroadcast(
                            ctx,
                            3000 + index * 10 + 1,
                            Intent(ctx, WidgetActionReceiver::class.java).apply {
                                action = WidgetActionReceiver.ACTION_STEP_TASK
                                putExtra(WidgetActionReceiver.EXTRA_TASK_ID, task.id)
                            },
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(ids.stepBtn, stepIntent)

                        val completeIntent = PendingIntent.getBroadcast(
                            ctx,
                            3000 + index * 10 + 2,
                            Intent(ctx, WidgetActionReceiver::class.java).apply {
                                action = WidgetActionReceiver.ACTION_COMPLETE_TASK
                                putExtra(WidgetActionReceiver.EXTRA_TASK_ID, task.id)
                            },
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(ids.doneBtn, completeIntent)
                        views.setOnClickPendingIntent(ids.container, openIntent)
                    }
                }

                appWidgetManager.updateAppWidget(widgetId, views)
            }
        }
    }

    private data class RowViewIds(
        val container: Int,
        val title: Int,
        val meta: Int,
        val bar: Int,
        val stepBtn: Int,
        val doneBtn: Int
    )
}
