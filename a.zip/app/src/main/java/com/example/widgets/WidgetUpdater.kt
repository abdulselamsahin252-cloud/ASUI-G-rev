package com.example.widgets

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.preferences.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object WidgetUpdater {
    fun requestUpdateAll(context: Context) {
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            updateAllSync(appContext)
        }
    }

    suspend fun updateAllSync(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val tasks = AppDatabase.getInstance(context).taskDao().getAllTasksOnce()
        val settings = SettingsRepository(context).getSettingsOnce()

        val summaryIds = manager.getAppWidgetIds(
            ComponentName(context, ProgressSummaryWidgetProvider::class.java)
        )
        if (summaryIds.isNotEmpty()) {
            ProgressSummaryWidgetProvider.updateWidgets(context, manager, summaryIds, tasks, settings)
        }

        val interactiveIds = manager.getAppWidgetIds(
            ComponentName(context, InteractiveTasksWidgetProvider::class.java)
        )
        if (interactiveIds.isNotEmpty()) {
            InteractiveTasksWidgetProvider.updateWidgets(context, manager, interactiveIds, tasks, settings)
        }
    }
}
