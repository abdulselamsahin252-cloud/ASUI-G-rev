package com.example

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.LocaleStorage
import com.example.data.preferences.SettingsRepository
import com.example.data.repository.TaskRepository
import com.example.ui.components.WallpaperBackground
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AdimAdimTheme
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.SettingsViewModelFactory
import com.example.ui.viewmodel.TaskViewModel
import com.example.ui.viewmodel.TaskViewModelFactory
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun attachBaseContext(newBase: Context) {
        val tag = LocaleStorage.getSavedLanguageTag(newBase)
        val wrapped = applyLocale(newBase, tag)
        super.attachBaseContext(wrapped)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val database = AppDatabase.getInstance(applicationContext)
        val taskRepository = TaskRepository(database.taskDao())
        val taskViewModelFactory = TaskViewModelFactory(taskRepository)

        val settingsRepository = SettingsRepository(applicationContext)
        val settingsViewModelFactory = SettingsViewModelFactory(settingsRepository)

        setContent {
            val taskViewModel: TaskViewModel = viewModel(factory = taskViewModelFactory)
            val settingsViewModel: SettingsViewModel = viewModel(factory = settingsViewModelFactory)
            val settings by settingsViewModel.settings.collectAsStateWithLifecycle()

            var showSettings by rememberSaveable { mutableStateOf(false) }

            LaunchedEffect(settings.themeMode) {
                val isLight = settings.themeMode == AppThemeMode.LIGHT
                enableEdgeToEdge(
                    statusBarStyle = if (isLight) {
                        SystemBarStyle.light(
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT
                        )
                    } else {
                        SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    },
                    navigationBarStyle = if (isLight) {
                        SystemBarStyle.light(
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT
                        )
                    } else {
                        SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                    }
                )
            }

            AdimAdimTheme(
                themeMode = settings.themeMode,
                hasWallpaper = settings.wallpaperPath != null
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    WallpaperBackground(
                        wallpaperPath = settings.wallpaperPath,
                        blurRadius = settings.wallpaperBlur,
                        sharpness = settings.wallpaperSharpness,
                        darkness = settings.wallpaperDarkness,
                        quality = settings.wallpaperQuality
                    )

                    AnimatedContent(
                        targetState = showSettings,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "screen_transition"
                    ) { isSettings ->
                        if (isSettings) {
                            SettingsScreen(
                                settings = settings,
                                onSelectTheme = settingsViewModel::setThemeMode,
                                onSelectLanguage = { newLang ->
                                    if (newLang != settings.language) {
                                        settingsViewModel.setLanguage(newLang) {
                                            recreate()
                                        }
                                    }
                                },
                                onPickWallpaper = settingsViewModel::saveWallpaper,
                                onClearWallpaper = settingsViewModel::clearWallpaper,
                                onBlurChange = settingsViewModel::setWallpaperBlur,
                                onSharpnessChange = settingsViewModel::setWallpaperSharpness,
                                onDarknessChange = settingsViewModel::setWallpaperDarkness,
                                onQualityChange = settingsViewModel::setWallpaperQuality,
                                onResetWallpaperAdjustments = settingsViewModel::resetWallpaperAdjustments,
                                onBack = { showSettings = false }
                            )
                        } else {
                            HomeScreen(
                                viewModel = taskViewModel,
                                onOpenSettings = { showSettings = true }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun applyLocale(context: Context, languageTag: String): Context {
        if (languageTag == AppLanguage.SYSTEM.tag) return context
        val locale = Locale.forLanguageTag(languageTag)
        Locale.setDefault(locale)
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return context.createConfigurationContext(config)
    }
}
