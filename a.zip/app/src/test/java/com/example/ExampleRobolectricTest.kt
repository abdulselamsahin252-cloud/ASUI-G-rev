package com.example

import android.content.Context
import android.content.res.Configuration
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.ProgressMode
import com.example.data.local.TaskCategory
import com.example.data.local.TaskEntity
import com.example.data.local.TaskPriority
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.CardDensity
import com.example.data.preferences.HomeLayoutMode
import com.example.data.preferences.SettingsRepository
import com.example.data.repository.TaskRepository
import com.example.notifications.NotificationHelper
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: TaskRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = TaskRepository(database.taskDao())
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun `app name matches ASUI GOREV and developer matches ASUI DESKTOP`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("ASUI GÖREV", context.getString(R.string.app_name))
        assertEquals("ASUI DESKTOP", context.getString(R.string.developer_name))
    }

    @Test
    fun `english localization provides translated strings`() {
        val baseContext = ApplicationProvider.getApplicationContext<Context>()
        val enConfig = Configuration(baseContext.resources.configuration).apply {
            setLocale(Locale.ENGLISH)
        }
        val enContext = baseContext.createConfigurationContext(enConfig)
        assertEquals("ASUI GÖREV", enContext.getString(R.string.app_name))
        assertEquals("Settings & Customization", enContext.getString(R.string.settings_title))
        assertEquals("AMOLED Black", enContext.getString(R.string.settings_theme_amoled))
        assertEquals("Neon Theme", enContext.getString(R.string.settings_theme_neon))
    }

    @Test
    fun `settings repository persists theme, home customization, and step amount`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val settingsRepo = SettingsRepository(context)
        assertEquals(10, settingsRepo.getSettingsOnce().defaultStepAmount)

        settingsRepo.setThemeMode(AppThemeMode.NEON)
        settingsRepo.setDefaultStepAmount(15)
        settingsRepo.setHomeLayoutMode(HomeLayoutMode.GRID)
        settingsRepo.setCardDensity(CardDensity.COMPACT)

        val updated = settingsRepo.settingsFlow.first()
        assertEquals(AppThemeMode.NEON, updated.themeMode)
        assertEquals(15, updated.defaultStepAmount)
        assertEquals(HomeLayoutMode.GRID, updated.homeLayoutMode)
        assertEquals(CardDensity.COMPACT, updated.cardDensity)
    }

    @Test
    fun `task supports custom step, duration deadline, and offline progress`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val deadlineMillis = System.currentTimeMillis() - 60_000L // expired 1 minute ago
        val pctTask = TaskEntity(
            title = "Raporu hazırla",
            category = TaskCategory.IS,
            priority = TaskPriority.YUKSEK,
            progressMode = ProgressMode.PERCENTAGE,
            progressPercent = 40,
            customStepAmount = 10,
            durationDays = 3,
            durationHours = 4,
            deadlineAt = deadlineMillis
        )
        val amountTask = TaskEntity(
            title = "Kitap oku",
            category = TaskCategory.EGITIM,
            priority = TaskPriority.ORTA,
            progressMode = ProgressMode.AMOUNT,
            completedAmount = 15,
            targetAmount = 50,
            unitLabel = "sayfa"
        )

        repository.upsertTask(pctTask)
        repository.upsertTask(amountTask)

        val saved = repository.allTasks.first()
        assertEquals(2, saved.size)

        val loadedPct = saved.first { it.title == "Raporu hazırla" }
        assertEquals(40, loadedPct.effectivePercent)
        assertEquals(10, loadedPct.effectiveStep(5))
        assertFalse(loadedPct.isCompleted)
        assertEquals(
            context.getString(R.string.deadline_expired),
            NotificationHelper.formatRemainingShort(context, loadedPct)
        )

        val loadedAmount = saved.first { it.title == "Kitap oku" }
        assertEquals(30, loadedAmount.effectivePercent)
        assertEquals(10, loadedAmount.effectiveStep(10))

        repository.upsertTask(loadedPct.copy(progressPercent = 100))
        val updated = repository.allTasks.first().first { it.title == "Raporu hazırla" }
        assertTrue(updated.isCompleted)
    }
}
